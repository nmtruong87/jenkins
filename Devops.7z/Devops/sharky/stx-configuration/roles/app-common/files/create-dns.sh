#!/bin/bash
name=$(hostname)
ip=$(hostname -I | awk '{print $1}')
action="CREATE"
env=$(jq -r ".env" /etc/stxcloud/metadata.json)
curl -s -X POST "http://${env}-rtcontroller:8040/manage-dns" -H "Content-Type:application/json" \
-d @<(cat <<EOF
{
  "name": "$name",
  "ip": "$ip",
  "action": "$action"
  }
EOF
)
