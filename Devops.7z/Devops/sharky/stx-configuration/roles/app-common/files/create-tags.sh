#!/bin/bash
name=$(hostname)
id=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
env=$(jq -r ".env" /etc/stxcloud/metadata.json)
curl -s -X POST "http://${env}-rtcontroller:8040/create-tags" -H "Content-Type:application/json" \
-d @<(cat <<EOF
{
  "id": "$id",
  "name": "$name"
  }
EOF
)
