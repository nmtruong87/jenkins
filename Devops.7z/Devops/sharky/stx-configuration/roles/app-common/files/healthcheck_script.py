import os
import argparse
import boto3
import requests
import json
import time
import logging

# Create and configure logger
logging.basicConfig(filename="/var/log/autoscale_result.log",
                    format='%(asctime)s %(message)s',
                    filemode='w')
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

parser = argparse.ArgumentParser()
parser.add_argument('--event', help='event detail', required=True)

args = parser.parse_args()
send_message = False

if args.event :
    event_detail = json.loads(args.event)
else:
    logger.info("[ERROR] Event is NULL!")
    os.exit(1)

logger.info("[INFO] Event: " + str(event_detail))

auto_scaling_group_name = event_detail["AutoScalingGroupName"]
lifecycle_action_result = "CONTINUE"
lifecycle_hook_name = event_detail["LifecycleHookName"]
instance_id = event_detail["EC2InstanceId"]
lifecycle_action_token = event_detail["LifecycleActionToken"]
auto_scaling_region = event_detail["EC2Region"]

cmd = "http://localhost:8000/isAlive.php"
if "generation" in auto_scaling_group_name:
    cmd = "http://localhost:9000/"

for i in range(120):
        try:
            logger.info("[INFO] Waiting for application...: "+ str(i))
            app_status = requests.get(cmd)

            if app_status.status_code == 200:
                logger.info("[INFO] Application is UP")
                logger.info(app_status.text)
                send_message = True
                break
            
            logger.info("[INFO] Application is NOT UP. Sleep 30 seconds...")
            logger.info(app_status.text)
        except Exception as e:
            logger.info("[EXCEPTION] " + str(e))

        time.sleep(30)

if send_message:
    for i in range(3):
        try:
            logger.info("[INFO] Send complete_lifecycle_action to Autoscale: "+ str(i))
            os.environ['AWS_DEFAULT_REGION'] = auto_scaling_region
            autoscaling = boto3.client("autoscaling")

            autoscaling.complete_lifecycle_action(LifecycleHookName=lifecycle_hook_name,
                AutoScalingGroupName=auto_scaling_group_name,
                LifecycleActionToken=lifecycle_action_token,
                LifecycleActionResult=lifecycle_action_result,
                InstanceId=instance_id)

            logger.info("[INFO] Send complete_lifecycle_action to Autoscale successfully")
            break
        except Exception as e:
            logger.info("[ERROR] NOT send to Autoscale.")
            logger.info("[EXCEPTION] " + str(e))
        time.sleep(30)
else:
    logger.info("[TIMEOUT] Application is NOT UP. NOT send to Autoscale.")
