#!/bin/bash
# 
# Goal   : Functions to manage sharky
# Author : JCB - 22.06.2020

function dieIfNotNull() {
  RETVAL=$?
  if [ $RETVAL != "0" ]; then
    echo "[FAILED] see console for more information"
    exit $RETVAL
  fi
}

function get_config(){
  ENV_KEY=$1
  CONF=`wget -qO- http://localhost/ticketing/$ENV`
  VALUE=`echo $CONF | jq -r '."'$ENV_KEY'"'`
  echo $VALUE
}

function get_port(){
  COMP=$1
  case $COMP in
    config-server)
      echo "80"
      ;;
    letsencrypt)
      echo "1080"
      ;;
    activemq)
      echo "61616"
      ;;
    squid)
      echo "3128"
      ;;
    runtimecontroller)
      echo "8040"
      ;;
  esac
}

function get_proxy(){
  local COMP=$1
  case $COMP in
    exporters)
      echo ""
      ;;
    runtimecontroller)
      echo ""
      ;;
    *)
      echo "-e HTTP_PROXY=$HTTPS_PROXY"
  esac
}