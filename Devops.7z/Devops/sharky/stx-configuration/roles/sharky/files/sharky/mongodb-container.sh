#!/bin/bash
ecr_repo=$1
tag=$2
name=$3

mongo_cluster_name="stxReplSet"
data_path="/opt/mongo_store/"
has_data=""
updated="false"
user=$(get_config frontend.mongodb.username)
pwd=$(get_config frontend.mongodb.password)

declare -a ports=("27017" "27018" "27019")

# Check data is exist
check_data_exists() {
    cd $data_path
    if [ -d "${data_path}/mongodb1" ] || [ -d "${data_path}/mongodb2" ] || [ -d "${data_path}/mongodb3" ]; then
        echo "true"
    else
        echo "false"
    fi
}
post_install(){
    openssl rand -base64 756 > /opt/mongo_store/cluster.key && chmod 0400 ${data_path}/cluster.key
    mkdir ${data_path}/mongodb{1..3}
}

# Creating new container
create_container() {  
    docker run -m 6GB -v /opt/mongo_store:/opt/mongodb --network host --name $name -d --restart always ${ecr_repo}:${tag}
}

# Add user for mongodb
add_user() {
    for port in "${ports[@]}"; do
        check=$(check_isMaster $port)
        if [ "$check" == "true" ]; then
                docker exec -i "$name" mongo --port "$port" < <(cat <<EOF
db.getSiblingDB("admin").createUser(
    {
        user: "$user",
        pwd: "$pwd",
        roles: ["clusterAdmin","readWriteAnyDatabase","dbAdminAnyDatabase","userAdminAnyDatabase"]

    }
);
EOF
)
            break
        fi
    done
}

# Create mongodb cluster
create_cluster() {
    docker exec -i $name mongo --port ${ports[0]} < <(cat <<EOF
config = {
    "_id": "$mongo_cluster_name",
    "members": [
        {
            "_id" : 0,
            "host" : "$(hostname):${ports[0]}"
        },
        {
            "_id" : 1,
            "host" : "$(hostname):${ports[1]}"
        },
        {
            "_id" : 2,
            "host" : "$(hostname):${ports[2]}"
        }
    ]
};
rs.initiate(config);
EOF
)
}

# Check which mongodb instance is master
check_isMaster() {
    docker exec $name mongo --port $1 --eval "printjson(rs.isMaster())"|grep "ismaster" |grep -q "true"
    if [ $? -eq 0 ]; then
        echo "true"
    else
        echo "false"
    fi
}

get_free_disk() {
    disk_name="sdb"
    disk_list=$(lsblk | grep -i "disk")

    while read disk; do
        d_name=$(awk '{ print $1 }' <<< $disk)
        d_size=$(awk '{ print $4 }' <<< $disk | grep -iEo "[0-9]+")

        [[ $d_size < 10 ]] && continue
        d_part=$(lsblk | grep -i "part" | grep -iEo "$d_name[0-9]+")
        if [[ -z $d_part ]]; then
            disk_name=$d_name
            break
        fi

        log "[INFO] $d_name is used. Try to find other free disk"
    done <<< $disk_list

    log "[INFO] Use $disk_name"

}

create_data_path() {
    if [[ -d $data_path ]]; then
        log "[INFO] ${data_path} is exist. No need to create it."
    else
        get_free_disk

        pv="/dev/$disk_name"
        vg="vg_master"
        lv="lv_mongodb"
        lv_path="/dev/$vg/$lv"

        log "[INFO] pvcreate $pv"
        pvcreate $pv > /dev/null 2>&1
        dieIfNotNull $?

        log "[INFO] vgextend $vg $pv"
        vgextend $vg $pv > /dev/null 2>&1
        dieIfNotNull $?

        log "[INFO] lvcreate -L 10G -n $lv $vg"
        echo "y" | lvcreate -L 10G -n $lv $vg > /dev/null 2>&1
        dieIfNotNull $?

        log "[INFO] mkfs -t ext4 -m 1 -v $lv_path"
        mkfs -t ext4 -m 1 -v $lv_path > /dev/null 2>&1
        dieIfNotNull $?

        log "[INFO] mkdir $data_path"
        mkdir $data_path > /dev/null 2>&1

        log "[INFO] mount $lv_path $data_path"
        mount $lv_path $data_path > /dev/null 2>&1
        dieIfNotNull $?

        CHECK_MOUNT=`cat /etc/fstab | grep -i "$lv_path \+${data_path::len-1}"`

        if [ $? -eq 0 ]; then
            log "[INFO] Mount point for $data_path has exists at /etc/fstab"
        else
            log "[INFO] add fstab for $lv_path to $data_path"
            echo "$lv_path ${data_path::len-1} ext4 errors=panic 0 2" | tee -a /etc/fstab
            dieIfNotNull $?
        fi

        log "[INFO] ${data_path} is created successfully."

    fi
}

main() {
    create_data_path
    has_data=$(check_data_exists)
    if [ $has_data = "true" ]; then
        log "[INFO] Creating new mongodb container."
        create_container
        log "[INFO] Waiting for mongodb container start"
    else
        log "[INFO] Creating folders for mongodb cluster."
        post_install
        dieIfNotNull $?
        log "[INFO] Creating mongodb container."
        create_container
        dieIfNotNull $?
        log "[INFO] Waiting for mongodb container start"
        sleep 10
        log "[INFO] Creating mongodb cluster."
        create_cluster
        log "[INFO] Cluster is starting."
        sleep 30
        log "[INFO] Adding user for mongodb."
        add_user
    fi
}
main "$@"