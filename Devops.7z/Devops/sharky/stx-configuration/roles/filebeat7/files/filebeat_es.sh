#!/bin/bash

# filebeat_es monitoring for check_mk.
# tests filebeat (service filebeat_es)

# Defined variables
FILEBEATLOG="/var/log/filebeat/filebeat_filebeat_es"
SERVICE="filebeat_es - "
ERRMSG="filebeat_es is running"
LVL=0

## Check filebeat_es service
systemctl is-active -q filebeat_es.service
if [[ $? -ne 0 ]]; then
    ERRMSG="Problem with filebeat_es: "
fi

ERRLOG=$(tail $FILEBEATLOG 2>/dev/null |grep -v INFO|tail -n 1|cut -d' ' -f3-)
if [[ $ERRLOG ]]; then
    ERRMSG="${ERRMSG} but $ERRLOG"
    echo "$ERRLOG" | grep -q "^WARN"
    #if [ $? -eq 0 ]; then # uncomment when ready
        LVL=1
    #else
    #    LVL=2
    #fi
else
    ERRLOG=$(tail $FILEBEATLOG 2>/dev/null |grep "INFO filebeat stopped"|tail -n 1|cut -d' ' -f3-)
    if [[ $ERRLOG ]]; then
        ERRMSG="${ERRMSG}$ERRLOG"
        LVL=1
    else
        LVL=0
    fi
fi

echo "$LVL $SERVICE - $ERRMSG"
