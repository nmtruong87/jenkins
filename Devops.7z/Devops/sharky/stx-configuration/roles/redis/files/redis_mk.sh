#!/bin/bash
master_port=6379
slave_port=6380
getState(){
    PORT=$1
    CST=$(redis-cli -p $PORT cluster info | grep cluster_state)

    if ! echo $CST| grep -q ok ; then
		echo "2 redis-$PORT - Cluster state KO"
        return
    fi
    redis-cli -p $PORT info memory | awk -F : '$1 ~ /used_memory$/{ u=$2;}  $1 ~ /maxmemory$/{m=$2;} END{
	if (m<1) { n=1+(4*u);}
	r=u/(n+m);
	u=u/1024;
	if (r < 0.7) {
	  printf("0 redis-'$PORT' - Cluster ok Used %d KB (%.3f)\n", u,r);
        } else {
	  printf("1 redis-'$PORT' - Cluster warn Used %d KB (%.3f) %d\n", u,r,m);
	} }'
}

getState $master_port
getState $slave_port