#!/bin/bash
# The script to ensure one master and one slave on a node in redis cluster.
LOG_FILE=/var/log/redis/cluster-fix.log

function log(){
  MSG=$1
  if [ -t 1 ]; then
    echo `date` $MSG
    echo `date` $MSG >> $LOG_FILE
  else
    echo `date` $MSG >> $LOG_FILE
  fi
}
# Sleep 30s
log "[INFO] Sleeping in 30s!"
sleep 30

# Check cluster
redis-cli cluster info|grep "cluster_state:ok"
if [ $? -ne 0 ]; then
  log "[ERROR] Cluster status is bad!"
  exit 1
fi

# Data file
data_file="/tmp/redis-nodes.txt"
redis-cli cluster nodes > $data_file

# Check all nodes.
awk '{ print $3 }' $data_file |grep fail
if [ $? -eq 0 ]; then
  log "[ERROR] Node status is bad!"
  exit 1
fi

# Get node having 2 masters
master_ip=$(grep master $data_file|awk '{print $2}'|cut -d":" -f1 |sort |uniq -c |awk '$1 == 2 { print $2}')
if [ -z $master_ip ]; then
  log "[INFO] Cluster is OK."
  exit 0
fi
log "[INFO] $master_ip have 2 masters."

# Get node having 2 slaves
slave_ip=$(grep slave $data_file|awk '{print $2}'|cut -d":" -f1 |sort |uniq -c|awk '$1 == 2 { print $2}')
if [ -z $slave_ip ]; then
  log "[ERROR] Could not failover!"
  exit 0
fi
log "[INFO] $slave_ip have 2 slaves."

# Get master ids
master_ids=$(grep $master_ip $data_file|awk '{ print $1}')

# Failover
for port in {6379,6380};do 
  master_id=$(grep "$slave_ip:$port" $data_file|awk '{ print $4}')
  for id in $master_ids;do
    if [ "$id" == "$master_id" ];then
      result=$(redis-cli -h $slave_ip -p $port cluster failover)
      if [ $result == "OK" ];then
        log "[INFO] Switched slave to master successfuly!"
        exit 0
      else
        log "[INFO] Switched slave to master failed!"
        exit 1
      fi
    fi
  done
done
