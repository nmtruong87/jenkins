#!/bin/bash
MASTER_PORT=6379
SLAVE_PORT=6380
hostname=$(hostname)
match="(([a-z]{1,4}[0-9]{1,2})redis[0-9])[a-c]"

get_ip() {
    name=$1
    ip=$(host -4 $name | cut -d' ' -f4)
    echo $ip
}
redis_check() {
    name=$1
    res1=$(redis-cli -h $name -p ${MASTER_PORT} ping 2>/dev/null)
    res2=$(redis-cli -h $name -p ${SLAVE_PORT} ping 2>/dev/null)
    if [[ $res1 == "PONG" ]] && [[ $res2 == "PONG" ]]; then
        echo 0
    else
        echo 1
    fi
}
create_cluster() {
    if [[ $hostname =~ $match ]]; then
        prefix="${BASH_REMATCH[1]}"
        redis1="${prefix}a"
        redis2="${prefix}b"
        redis3="${prefix}c"
        check1=$(redis_check $redis1)
        check2=$(redis_check $redis2)
        check3=$(redis_check $redis3)
        if [[ $check1 -eq 0 ]] && [[ $check2 -eq 0 ]] && [[ $check3 -eq 0 ]]; then
            redis-cli -p ${MASTER_PORT} cluster info|grep -q "cluster_state:ok"
            if [[ $? -ne 0 ]]; then
                ip1=$(get_ip $redis1)
                ip2=$(get_ip $redis2)
                ip3=$(get_ip $redis3)
                echo yes | redis-cli --cluster create "${ip1}":6379 "${ip2}":6379 "${ip3}":6379 \
                "${ip2}":6380 "${ip3}":6380 "${ip1}":6380 --cluster-replicas 1 > /dev/null 2>&1
            fi
        fi
    fi
}
create_cluster