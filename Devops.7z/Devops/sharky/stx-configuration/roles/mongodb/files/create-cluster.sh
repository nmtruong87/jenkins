#!/bin/bash

# This script is used for creating mongodb cluster.
cluster_name="rs0"
hostname=$(hostname)
match="(([a-z]{1,4}[0-9]{1,2})mongo[0-9])[a-c]"
port=27017

# Get value from config server.
get_config(){
  ENV_KEY=$1
  VALUE=$(wget -qO- http://${env}-config-server/ticketing/${env}|grep ${ENV_KEY}| cut -d \" -f4)
  echo $VALUE
} 

# Create MongoDB cluster.
create_cluster() {
for ext in a b c;do  
  nc -vz "${prefix}${ext}" "${port}" > /dev/null 2>&1
  if [ $? -ne 0 ];then
    echo "INFO - Need 3 hosts to init a cluster"
    exit 1
  fi
done
mongosh --quiet < <(cat <<EOF
config = {
    "_id": "$cluster_name",
    "members": [
        {
            "_id" : 0,
            "host" : "${prefix}a:${port}"
        },
        {
            "_id" : 1,
            "host" : "${prefix}b:${port}"
        },
        {
            "_id" : 2,
            "host" : "${prefix}c:${port}"
        }
    ]
};
rs.initiate(config);
EOF
)     
}

# Add user mongodb.
add_user() {
mongosh --quiet < <(cat <<EOF
db.getSiblingDB("admin").createUser(
    {
        user: "$user",
        pwd: "$pwd",
        roles: ["clusterAdmin","readWriteAnyDatabase","dbAdminAnyDatabase","userAdminAnyDatabase"]

    }
);
EOF
)
}

main() {
  if [[ $hostname =~ $match ]]; then
    prefix="${BASH_REMATCH[1]}"
    # Create cluster mongodb
    echo "INFO - Creating cluster."
    create_cluster
    echo "Wating for cluster starting,"
    sleep 30

    # Check cluster status
    repl_stt=$(mongosh --quiet --eval "printjson(rs.status().ok)")
    if [ $repl_stt -eq 1 ]; then
      # Create user for mongodb
      env="${BASH_REMATCH[2]}"
      user=$(get_config frontend.mongodb.username)
      pwd=$(get_config frontend.mongodb.password)
      echo "INFO - Creating user mongodb"
      add_user
      repl_stt2=$(mongosh -u $user -p $pwd --quiet --eval "printjson(rs.status().ok)")
      if [ $repl_stt2 -eq 1 ]; then
        echo "INFO - Create user and cluster successfully."
        exit 0
      else
        echo "ERROR - Could not reate user or cluster!"
        exit 1
      fi
    else
      echo "ERROR - Cluster is not OK now."
    fi
  else
    echo "ERROR - Hostname is not match!."
    exit 1
  fi
}
main "$@"
