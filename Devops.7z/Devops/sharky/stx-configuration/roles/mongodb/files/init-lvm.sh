#!/bin/bash
PVNAME="/dev/sdb"
VGNAME="vg_master"
LVNAME="mongo"
MONGO_PATH="/var/lib/mongodb"

if ! lsblk |grep -q sdb;then
    echo "INFO - Disk sdb not exists !"
    exit 1
fi
# Create physical volumn
if pvs|grep -q $PVNAME;then
    echo "INFO - Physical volumn $PVNAME exists !"
    exit 0
else
    echo "INFO - Crate physical volumn $PVNAME"
    pvcreate $PVNAME
fi
# Create logical volumn
if lvs|grep -q "$LVNAME";then
    echo "INFO - Logical volumn $LVNAME exists !"
    exit 0
else
    echo "INFO - Crate logical volumn $LVNAME"
    lvcreate -n $LVNAME -l 100%FREE $VGNAME
    mkfs.ext4 "/dev/${VGNAME}/${LVNAME}"
fi

# Create mongodb folder
if [ -d $MONGO_PATH ];then
    echo "INFO - $MONGO_PATH exists !"
    exit 0
else
    mkdir $MONGO_PATH
fi

# Configure file fstab
if grep -q $MONGO_PATH /etc/fstab;then
    echo "INFO - $MONGO_PATH exists in file fstab !"
    exit 0
else
    echo "/dev/${VGNAME}/${LVNAME}  ${MONGO_PATH}   ext4   errors=panic   0   2" >> /etc/fstab
    mount -a
fi
