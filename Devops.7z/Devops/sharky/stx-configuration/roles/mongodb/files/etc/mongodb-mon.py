#!/usr/bin/python
from pymongo import MongoClient
import urllib
import json
import re
import socket
from datetime import datetime

hostname = socket.gethostname()
match = re.search('(([a-z]+\d+)mongo\d)[a-c]',hostname)
prefix = match.group(1)
env = match.group(2)

# Get user, pass from env-config-server
def get_config(key):
  url = "http://{}-config-server/ticketing/{}".format(env,env)
  response = urllib.urlopen(url)
  data = json.loads(response.read())
  return data[key]

# Check Cluster State
def cmk_cluster(user, password):
  try:
    password = urllib.quote_plus(password)
    uri = 'mongodb://{}:{}@{}a:27017,{}b:27017,{}c:27017'.format(user,password,prefix,prefix,prefix)
    # timeout is 2s
    conn = MongoClient(uri,serverSelectionTimeoutMS = 2000)
    data = conn.admin.command('replSetGetStatus')
    if data["ok"] == 1.0:
      print("0 mongodb-cluster - MongoDB Cluster is OK.")
      return data
    else:
      print("2 mongodb-cluster - MongoDB Cluster is KO.")
      exit()

  except:
      print("2 mongodb-cluster - MongoDB Cluster is KO.")

# Check Node State
def cmk_node(data):
  for node in data["members"]:
    nodename = node["name"].split(":")[0]
    if hostname == nodename:
      if node["health"] == 1.0:
        print("0 mongodb-node - Node is OK. State: {}".format(node["stateStr"]))
        break
      else:
        print("2 mongodb-node - Node is KO. State: {}".format(node["stateStr"]))
        exit()

# Check Replication Lag
def cmk_lag(data):
  for node in data["members"]:
    if node["stateStr"] == "PRIMARY":
      masterOT = node["optimeDate"]
    nodename = node["name"].split(":")[0]
    if hostname == nodename:
      nodeOT = node["optimeDate"]
  
  diff = masterOT - nodeOT
  lag = diff.total_seconds()
  print("P mongodb-lag lag={};600;3600".format(lag))



def main():
  user = get_config("frontend.mongodb.username")
  pwd = get_config("frontend.mongodb.password")
  data=cmk_cluster(user, pwd)
  cmk_node(data)
  cmk_lag(data)
  
if __name__ == "__main__":
  main()