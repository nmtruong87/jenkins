#!/bin/bash
WORKSPACE=/usr/lib/stx-configuration
HOSTS=${WORKSPACE}/hosts
LOGS=/var/log/stx-configuration.log
METADATA=/etc/stxcloud/metadata.json
SUPPORTED_TYPES=("internet1 itr1 itr2 bil1 tnac1 generation1 efr1")
SERVICE_TYPES=("sharky3 mongo1 redis7")
MARKER=/usr/lib/stx-configuration/marker

function write_log() {
    local msg=$1
    echo `date "+%F %H:%M:%S"` ${msg} | tee -a ${LOGS}
}

function run_ansible() {
    local phase=$1
    local playbook_file=$2

    write_log "START playbook $playbook_file"
    echo "$phase-INPROGRESS" > $MARKER

    if type runtimecontroller-agent > /dev/null 2>&1; then
        runtimecontroller-agent
    fi

    cd $WORKSPACE && ansible-playbook $playbook_file | tee -a ${LOGS}

    result=$(tail -2 ${LOGS})
    isOK="NOT_OK"
    if [[ " ${result} " =~ " failed=0 " ]]; then
        isOK="OK"
    fi

    echo $phase-$isOK > $MARKER
    if type runtimecontroller-agent > /dev/null 2>$1; then
        runtimecontroller-agent
    fi

    write_log "END playbook $playbook_file - $isOK"

    if [[ $isOK == "NOT_OK" ]]; then
        exit 1
    fi
}

touch $LOGS
write_log "START stx-configuration."
if [ ! -f "$METADATA" ]; then
    write_log "$METADATA does not found. Exited :("
    exit 1
fi

ROOT_GROUP=$(cat ${METADATA} | jq .type -r)
ENV=$(cat ${METADATA} | jq .env -r)
SITE=$(cat ${METADATA} | jq .site -r)
DRS_GVA=("p14 p15")
DRS_SEB=("p16 p20 p44")

write_log "Verify ${METADATA}"
if [[ ! " ${SUPPORTED_TYPES[*]} " =~ " ${ROOT_GROUP} " ]] && [[ ! " ${SERVICE_TYPES[*]} " =~ " ${ROOT_GROUP} " ]]; then
    write_log "stx-configuration does not support ${ROOT_GROUP}"
    exit 0
fi

write_log "Verify OK"

echo "[${ROOT_GROUP}]" > $HOSTS
echo "127.0.0.1 ansible_connection=local ansible_python_interpreter=/usr/bin/python3" >> $HOSTS
echo "[${SITE}:children]" >> $HOSTS
echo ${ROOT_GROUP} >> $HOSTS

write_log "Checking ENV is DRS site or not..."
if [[ " ${DRS_GVA[*]} " =~ " ${ENV} " && ${SITE} == "gv2" || " ${DRS_SEB[*]} " =~ " ${ENV} " &&  ${SITE} == "se2" ]]; then
    write_log "This ENV is DRS site"
    echo "[${ENV}-drs:children]" >> $HOSTS
else
    write_log "This ENV is not DRS site. Install normally ..."
    echo "[${ENV}:children]" >> $HOSTS
fi

echo ${ROOT_GROUP} >> $HOSTS

if [ -f "$MARKER" ]; then
    rm $MARKER
fi

write_log "Generated inventory ${HOSTS}"

if [ -f "$MARKER" ]; then
    rm $MARKER
fi

if [[ " ${SERVICE_TYPES[*]} " =~ " ${ROOT_GROUP} " ]]; then
    run_ansible CONFIG services.yml

elif [[ " ${SUPPORTED_TYPES[*]} " =~ " ${ROOT_GROUP} " ]]; then

    run_ansible CONFIG config.yml

    run_ansible INSTALL_APP install_app.yml
fi

write_log "END stx-configuration."