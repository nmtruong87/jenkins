# HTTPPROXY
We use this ansible playbook to create a reverse proxy in order to be able to use resources of two differente private networks

## Usage
```bash
ansible-playbook -Kki env httpproxy.yml
```

## Notes
- To run the ansible in "check mode" add the --check parameter
```bash
ansible-playbook -Kki env httpproxy.yml --check
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
STX-ELCA