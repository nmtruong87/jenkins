import requests
import sys
import dateutil.parser
from datetime import datetime

file = '/var/lib/node_exporter/textfile_collector/stx_db_checks.prom'
f = open(file, 'r+')
f.truncate(0)
queries = [
    {
        "url": "http://localhost:8086/query?pretty=true",
        "params": {"db":"oramon","q":"SELECT last(\"metric_value\") FROM \"oracle_sysmetric\" WHERE \"metric_name\"='Average_Active_Sessions' GROUP BY \"db\""},
        "metric": "average_active_sessions"
    },
    {
        "url": "http://localhost:8086/query?pretty=true",
        "params": {"db":"oramon","q":"SELECT last(\"lock_cnt\") FROM \"oracle_block_cnt\" GROUP BY \"db\""},
        "metric": "locked_sessions"
    },
    {
        "url": "http://localhost:8086/query?pretty=true",
        "params": {"db":"oramon","q":"SELECT last(\"metric_value\") FROM \"oracle_sysmetric\" WHERE \"metric_name\"='Redo_Generated_Per_Sec' GROUP BY \"db\""},
        "metric": "redo"
    },
    {
        "url": "http://localhost:8086/query?pretty=true",
        "params": {"db":"oramon","q":"SELECT last(\"percent_used\") FROM \"oracle_tablespaces\" GROUP BY \"tbs_name\",\"db\""},
        "metric": "tablespace_pct",
        "type": "tbs"
    },
    {
        "url": "http://localhost:8086/query?pretty=true",
        "params": {"db":"sqlmons","q":"SELECT last(\"system_idle_cpu\") FROM \"sqlserver_cpu\" GROUP BY \"sql_instance\""},
        "metric": "system_idle_cpu",
        "type": "ssrs",
        "db": "sql_instance"
    },
    {
        "url": "http://localhost:8086/query?pretty=true",
        "params": {"db":"sqlmon","q":"SELECT last(\"db_offline\") FROM \"sqlserver_server_properties\" GROUP BY \"sql_instance\""},
        "metric": "db_offline",
        "type": "ssrs",
        "db": "sql_instance",
        "set_time": "true"
    },
    {
        "url": "http://localhost:8086/query?pretty=true",
        "params": {"db":"activemq","q":"SELECT last(\"QueueSize\") FROM \"activemq.queue\" GROUP BY \"jolokia_agent_url\""},
        "metric": "queue_size",
        "db": "activemq",
        "type": "activemq",
        "dbIsHost": "jolokia_agent_url"
    }
]

with open(file, 'w') as f:
    for query in queries:
        response = requests.get(query['url'], headers={'Content-type': 'application/json'}, params=query['params']).json()
        try:
            for serie in response['results'][0]['series']:
                if 'db' not in query:
                    db = serie['tags']['db']
                else:
                    if query['db'] not in serie['tags']:
                        if 'dbIsHost' in query:
                            db = serie['tags'][query['dbIsHost']]
                        else:
                            db = query['db']
                    else:
                        db = serie['tags'][query['db']]
                if 'type' not in query:
                    tp = "oracle"
                    tbsname = ""
                elif query['type'] == 'tbs':
                    tp = "oracle"
                    tbsname = ', tablespace="' + serie['tags']['tbs_name'] + '"'
                else:
                    tp = query['type']
                if 'set_time' not in query:
                    result = serie['values'][0][1]
                else:
                    date = dateutil.parser.parse(serie['values'][0][0])
                    now = datetime.utcnow()
                    diff = now - date.replace(tzinfo=None)
                    result = diff.total_seconds() / 60
                sys.stdout = f
                print('database_check{type="' + tp + '", db="' + db + '", metric="' + query['metric'] + '"' + tbsname + '} ' + str(result))
        except:
            print('database_check_fail{type="' + query['type'] + '"} ' + str(1))
