#!/bin/bash

current_date=$(date "+%Y-%m-%d")
prometheus_backup_dir=/var/lib/prometheus/prometheus/snapshots
influxdb_backup_dir=/var/lib/influxdb/backup
temp_file=/var/lib/node_exporter/textfile_collector/backup_status.prom.$$
file=/var/lib/node_exporter/textfile_collector/backup_status.prom

if [ ! -d $prometheus_backup_dir ]; then
 echo "backup_status{type=\"prometheus\", status=\"KO\", info=\"backup_not_running\"} 1" >> $temp_file
else
 cd $prometheus_backup_dir
 prometheus_lastest_backup=$(ls -rtd */ | tail -1)
 prometheus_lastest_backup_date=$(stat ${prometheus_lastest_backup} | grep Change | awk '{print $2}')
 if [[ $(( ${10#prometheus_lastest_backup_date} ))  -eq  $(( ${10#current_date} )) ]]; then
  echo "backup_status{type=\"prometheus\", status=\"OK\", info=\"backup_is_running\"} 0" >> $temp_file
 else
  echo "backup_status{type=\"prometheus\", status=\"KO\", info=\"backup_${current_date}_missing\"} 1" >> $temp_file
 fi
fi

if [ ! -d $influxdb_backup_dir ]; then
 echo "backup_status{type=\"influxdb\", status=\"KO\", info=\"backup_not_running\"} 1" >> $temp_file
else
 cd $influxdb_backup_dir
 influxdb_lastest_backup=$(ls -rtd */ | tail -1)
 influxdb_lastest_backup_date=$(stat ${influxdb_lastest_backup} | grep Change | awk '{print $2}')
 if [[ $(( ${10#influxdb_lastest_backup_date} )) -eq  $(( ${10#current_date} )) ]]; then
  echo "backup_status{type=\"influxdb\", status=\"OK\", info=\"backup_is_running\"} 0" >> $temp_file
 else
  echo "backup_status{type=\"influxdb\", status=\"KO\", info=\"backup_${current_date}_missing\"} 1" >> $temp_file
 fi
fi

cp $temp_file $file
rm -f $temp_file
