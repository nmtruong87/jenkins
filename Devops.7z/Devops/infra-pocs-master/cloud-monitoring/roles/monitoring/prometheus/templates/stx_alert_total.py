import requests
import sys

path = '/var/lib/node_exporter/textfile_collector/stx_alert_total.prom'
f = open(path, 'r+')
f.truncate(0)
{% if sites == "HRP"%}
response = requests.get('http://prometheus.hrp.secutix.net:9090/api/v1/rules')
{% endif %}
{% if sites == "SEB" %}
response = requests.get('http://prometheus.seb.secutix.net:9090/api/v1/rules')
{% endif %}
json = response.json()
result = {}
for group in json['data']['groups']:
    for rule in group['rules']:
        for label, value in rule['labels'].items():
            if label != 'description' and label != 'doc':
                if value in result:
                    result[value] += 1
                else:
                    result[value] = 1
with open(path, 'w') as f:
    for entry, count in result.items():
        sys.stdout = f
        print('total_alerts{type="' + entry + '"} ' + str(count))