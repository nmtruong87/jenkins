import logging
import os
import re
import requests
import json

from dotenv import load_dotenv
from slack_bolt import App
from slack_bolt.adapter.socket_mode import SocketModeHandler
from pathlib import Path
from influx import InfluxDB
from slack_bolt.async_app import AsyncApp

env_path = Path('.') / '.env-template'
load_dotenv(dotenv_path=env_path)

SLACK_APP_TOKEN = os.environ["SLACK_APP_TOKEN"]
SLACK_BOT_TOKEN = os.environ["SLACK_BOT_TOKEN"]

app = App(token=SLACK_BOT_TOKEN, name="Joke Bot")
logger = logging.getLogger(__name__)


influxdb_client = InfluxDB('http://cs1cloudmon1a.hrp.secutix.net:8086')

list_job = ('STX_build-install-smoke-tests','STX_build-install-tests','STX_build-install-tests-jacoco-fitnesse','STX_build-install-tests-jacoco-selenium','STX_build-install-tests-jacoco', 'STX_qa20_build-install-tests', '_env-install-int1','_env-install-int2','_env-install-perf15','_env-install-qa21','_env-install-qa22')
mapping = {
        'STX_build-install-smoke-tests':'INT0_smoke', 
        'STX_build-install-tests':'INT0_full',
        'STX_build-install-tests-jacoco-fitnesse':'INT0_fitnesse_jacoco',
        'STX_build-install-tests-jacoco-selenium':'INT0_selenium_jacoco',
        'STX_build-install-tests-jacoco':'INT0_full_jacoco',
        'STX_qa20_build-install-tests':'QA20',
        '_env-install-int1':'INT1_install',
        '_env-install-int2':'INT2_install',
        '_env-install-perf15':'PERF15_install',
        '_env-install-qa21':'QA21_install',
        '_env-install-qa22':'QA22_install'
}

array_env_datacopy = ["export_int1", "export_qa21", "weekly_int1", "weeky_int2", "val1", "val0", "qa30", "qa11", "qa10", "int4", "int2", "int1", "dev2", "dev1", "dev0", "dev12"]
mapping_data_copy = {
    'export_int1':'Env_export_ref_data_MINT1',
    'export_qa21':'Env_export_ref_data_MQA21',
    'weekly_int1':'Env_Weekly_Data_INT1',
    'weekly_int2':'Env_Weekly_Data_INT2',
    'val1':'Env_Daily_Data_VAL1',
    'val0':'Env_Daily_Data_VAL0',
    'qa30':'Env_Daily_Data_QA30',
    'qa11':'Env_Daily_Data_QA11',
    'qa10':'Env_Daily_Data_QA10',
    'int4':'Env_Daily_Data_INT4',
    'int2':'Env_Daily_Data_INT2',
    'int1':'Env_Daily_Data_INT1',
    'dev2':'Env_Daily_Data_DEV2',
    'dev1':'Env_Daily_Data_DEV1',
    'dev0':'Env_Daily_Data_DEV0',
    'dev12':'Env_Daily_Data_DEV12'
}

def get_jira_info(jira):
    
    #get jira assgine and jira status
    url = "https://jira.secutix.com/rest/api/2/issue/" + jira + "?fields=status,assignee"
    x = requests.get(url, auth = ('external_system', 'Zi5L6pW8t9a'))
    jira_assignee = "Unassigne"
    if x.json()["fields"]["assignee"] is not None:
        jira_assignee = x.json()["fields"]["assignee"]["name"]
    jira_status = x.json()["fields"]["status"]["name"]
    jira_info = {
        "assignee": jira_assignee,
        "status": jira_status
    }
    return jira_info

#@app.message(re.compile(r"STX|ENV|@graf"))
@app.message("")
def get_issue_summary(message, say, client):
    #Add detail
    if message["type"] == "message":
        channel_type = message["channel_type"]
        dm_channel = message["channel"]
        user = message['user']

        #get conversation
        conversation = client.conversations_replies (
            channel=message["channel"],
            ts=message["ts"]
        )  
        conversation_parent = client.conversations_replies (
            channel=message["channel"],
            ts=conversation["messages"][0]["thread_ts"]
        )
        #get text parent from slack
        job = conversation_parent["messages"][0]["text"]
        if(conversation_parent["messages"][0]["subtype"] == "bot_message"):
            job = conversation_parent["messages"][0]["attachments"][0]["fields"][0]["value"]
        link_job=re.findall(r'(http[s]?://[^\s^<>]+)', job)[0]

        #Send issueSummary to influxdb 
        for job_name in list_job:
            if job_name in link_job:
                #send message to influx
                text = message["text"]
                data = influxdb_client.select_where('dailyreport', mapping[job_name],fields='buildJobURL, buildType, buildVersion, buildDate, buildResult, buildRemark, issueSummary, issueStatus, jiraID, assignee, detail', where='time > 0', desc=True, limit=10)
                #print(data)
                fields_count = len(data["results"][0]["series"][0]["columns"])
                value_count = len(data["results"][0]["series"][0]["values"])
                for j in range(value_count):
                    link_of_row = data["results"][0]["series"][0]["values"][j][1]
                    if link_job.find(link_of_row) != -1:
                        my_data = {}
                        for i in range(fields_count):
                            print("-----------------------------------------------------------")
                            print(i)
                            print(data["results"][0]["series"][0]["columns"][i])
                            print(data["results"][0]["series"][0]["values"][j][i])
                            my_data[data["results"][0]["series"][0]["columns"][i]] = data["results"][0]["series"][0]["values"][j][i]
                            print("-----------------------------------------------------------")
                        #my_data["link"] = data["results"][0]["series"][0]["values"][0][1]
                        if my_data["detail"] == None:
                            my_data["detail"] = ""
                        #my_data["detail"] = ""
                        my_data["detail"] += text
                        my_data["detail"] += "   |   "
                        influxdb_client.write('dailyreport', mapping[job_name], fields=my_data, tags={'tag_build_type': mapping[job_name], 'tag_build_job_url': link_of_row})
                        print(my_data)
                        break

    if "@graf" in message["text"]:
        channel_type = message["channel_type"]
        dm_channel = message["channel"]
        user = message['user']

        #get conversation
        conversation = client.conversations_replies (
            channel=message["channel"],
            ts=message["ts"]
        )  
        conversation_parent = client.conversations_replies (
            channel=message["channel"],
            ts=conversation["messages"][0]["thread_ts"]
        )
        #get text parent from slack
        job = conversation_parent["messages"][0]["text"]
        #print(conversation_parent)
        if(conversation_parent["messages"][0]["subtype"] == "bot_message"):
            job = conversation_parent["messages"][0]["attachments"][0]["fields"][0]["value"]
        #link_job = re.search("(?P<url>https?://[^\s]+)", job).group("url").replace(">","")
        link_job=re.findall(r'(http[s]?://[^\s^<>]+)', job)[0]

        #Send issueSummary to influxdb 
        for job_name in list_job:
            if job_name in link_job:
                #send message to influx
                text = message["text"].replace("@graf","")
                data = influxdb_client.select_where('dailyreport', mapping[job_name],fields='buildJobURL, buildType, buildVersion, buildDate, buildResult, buildRemark, issueSummary, issueStatus, jiraID, assignee, detail', where='time > 0', desc=True, limit=10)
                print("data query from db")
                print(data)
                fields_count = len(data["results"][0]["series"][0]["columns"])
                value_count = len(data["results"][0]["series"][0]["values"])
                for j in range(value_count):
                    link_of_row = data["results"][0]["series"][0]["values"][j][1]
                    if link_job.find(link_of_row) != -1:
                        my_data = {}
                        for i in range(fields_count):
                            print("-----------------------------------------------------------")
                            print(i)
                            print(data["results"][0]["series"][0]["columns"][i])
                            print(data["results"][0]["series"][0]["values"][j][i])
                            my_data[data["results"][0]["series"][0]["columns"][i]] = data["results"][0]["series"][0]["values"][j][i]
                            print("-----------------------------------------------------------")
                        #my_data["link"] = data["results"][0]["series"][0]["values"][0][1]
                        my_data["issueSummary"] = text
                        influxdb_client.write('dailyreport', mapping[job_name], fields=my_data, tags={'tag_build_type': mapping[job_name], 'tag_build_job_url': link_of_row})
                        print(my_data)
                        break

        #Add reaction
        api_response = client.reactions_add(
            channel=message["channel"],
            timestamp=message["ts"],
            name="grafana",
        )

    if ("STX" in message["text"])|("ENV" in message["text"]):
        #get conversation
        conversation = client.conversations_replies (
            channel=message["channel"],
            ts=message["ts"]
        )  
        conversation_parent = client.conversations_replies (
            channel=message["channel"],
            ts=conversation["messages"][0]["thread_ts"]
        )
        #get text parent from slack
        job = conversation_parent["messages"][0]["text"]
        if(conversation_parent["messages"][0]["subtype"] == "bot_message"):
            job = conversation_parent["messages"][0]["attachments"][0]["fields"][0]["value"]
        #link_job = re.search("(?P<url>https?://[^\s]+)", job).group("url").replace(">","")
        link_job = re.findall(r'(http[s]?://[^\s^<>]+)', job)[0]

        array = re.split("\s", message["text"])
        for a in array:
            #check text contain jira
            if re.search(r"(STX|ENV)(-|_)(\d{5,6})", a):
                #Get jira
                jira = re.search(r"(STX|ENV)(-|_)(\d{5,6})", a).group(1) + re.search(r"(STX|ENV)(-|_)(\d{5,6})", a).group(2) + re.search(r"(STX|ENV)(-|_)(\d{5,6})", a).group(3)

                #Send issueSummary to influxdb 
                for job_name in list_job:
                    if job_name in link_job:
                        #send message to influx
                        data = influxdb_client.select_where('dailyreport', mapping[job_name],fields='buildJobURL, buildType, buildVersion, buildDate, buildResult, buildRemark, linkReportDetail, issueSummary, issueStatus, jiraID, assignee, detail', where='time > 0', desc=True, limit=10)
                        #print(data)
                        fields_count = len(data["results"][0]["series"][0]["columns"])
                        value_count = len(data["results"][0]["series"][0]["values"])
                        for j in range(value_count):
                            link_of_row = data["results"][0]["series"][0]["values"][j][1]
                            print(link_of_row)
                            print(link_job)
                            if link_job.find(link_of_row) != -1:
                                my_data = {}
                                for i in range(fields_count):
                                    print("-----------------------------------------------------------")
                                    print(i)
                                    print(data["results"][0]["series"][0]["columns"][i])
                                    print(data["results"][0]["series"][0]["values"][j][i])
                                    my_data[data["results"][0]["series"][0]["columns"][i]] = data["results"][0]["series"][0]["values"][j][i]
                                    print("-----------------------------------------------------------")
                                #my_data["link"] = data["results"][0]["series"][0]["values"][0][1]
                                my_data["jiraID"] = jira
                                jira_info = get_jira_info(jira)
                                my_data["assignee"] = jira_info["assignee"]
                                my_data["issueStatus"] = jira_info["status"]
                                influxdb_client.write('dailyreport', mapping[job_name], fields=my_data, tags={'tag_build_type': mapping[job_name], 'tag_build_job_url': link_of_row})
                                print(my_data)
                                break

    if "@data" in message["text"]:
        text = message["text"]
        #get list env from slack message
        start_point = text.find('[')
        end_point = text.find(']')
        list_text_env_issue = text[start_point+1:end_point]
        list_env_issue = re.split(",", list_text_env_issue)
        # Get issue_summary from text
        issue_summary = str(text[end_point+1:])
        #Check env in list_env_issue have in database and put issue to database
        for env in list_env_issue:
            if env in array_env_datacopy:
                data = influxdb_client.select_where('dailyreport', mapping_data_copy[env],fields='buildJobURL, buildType, buildDate, buildResult, issueSummary, issueStatus, jiraID, assignee', where='time > 0', desc=True, limit=10)
                print(data)
                fields_count = len(data["results"][0]["series"][0]["columns"])
                my_data = {}
                for i in range(fields_count):
                    print("-----------------------------------------------------------")
                    print(i)
                    print(data["results"][0]["series"][0]["columns"][i])
                    print(data["results"][0]["series"][0]["values"][0][i])
                    my_data[data["results"][0]["series"][0]["columns"][i]] = data["results"][0]["series"][0]["values"][0][i]
                    print("-----------------------------------------------------------")
                my_data["issueSummary"] = issue_summary
                influxdb_client.write('dailyreport', mapping_data_copy[env], fields=my_data, tags={'tag_data_build_type': mapping_data_copy[env], 'tag_build_job_url': data["results"][0]["series"][0]["values"][0][1]})
                print(my_data)
                break
        #Add reaction
        api_response = client.reactions_add(
            channel=message["channel"],
            timestamp=message["ts"],
            name="grafana",
        )

    if "@jira" in message["text"]:
        text = message["text"]
        #get list env from slack message
        start_point = text.find('[')
        end_point = text.find(']')
        list_text_env_issue = text[start_point+1:end_point]
        list_env_issue = re.split(",", list_text_env_issue)
        # Get jira from text
        array_split_message = re.split("\s", message["text"])
        for a in array_split_message:
            #check text contain jira
            if re.search(r"(STX|ENV)(-|_)(\d{5,6})", a):
                #Get jira
                jira = re.search(r"(STX|ENV)(-|_)(\d{5,6})", a).group(1) + re.search(r"(STX|ENV)(-|_)(\d{5,6})", a).group(2) + re.search(r"(STX|ENV)(-|_)(\d{5,6})", a).group(3)
                jira = str(jira)
                #Check env in list_env_issue have in database and put issue to database
                for env in list_env_issue:
                    if env in array_env_datacopy:
                        data = influxdb_client.select_where('dailyreport', mapping_data_copy[env],fields='buildJobURL, buildType, buildDate, buildResult, issueSummary, issueStatus, jiraID, assignee', where='time > 0', desc=True, limit=10)
                        fields_count = len(data["results"][0]["series"][0]["columns"])
                        my_data = {}
                        for i in range(fields_count):
                            print("-----------------------------------------------------------")
                            print(data["results"][0]["series"][0]["columns"][i])
                            print(data["results"][0]["series"][0]["values"][0][i])
                            my_data[data["results"][0]["series"][0]["columns"][i]] = data["results"][0]["series"][0]["values"][0][i]
                            print("-----------------------------------------------------------")
                        my_data["jiraID"] = jira
                        jira_info = get_jira_info(jira)
                        my_data["assignee"] = jira_info["assignee"]
                        my_data["issueStatus"] = jira_info["status"]
                        influxdb_client.write('dailyreport', mapping_data_copy[env], fields=my_data, tags={'tag_data_build_type': mapping_data_copy[env], 'tag_build_job_url': data["results"][0]["series"][0]["values"][0][1]})
                        print(my_data)
                        break
    


def main():
    handler = SocketModeHandler(app, SLACK_APP_TOKEN)
    handler.start()


if __name__ == "__main__":
    main()
