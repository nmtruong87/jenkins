#!/bin/bash
# -- Variables
BASE_PATH=/var/lib/node_exporter
DEST_FILE=${BASE_PATH}/textfile_collector/rds4prometheus.prom
# -- Getting metrics from CloudWatch
/usr/bin/python ${BASE_PATH}/rds4prometheus.py > ${DEST_FILE}
# -- Adding prometheus format
sed -i 's/\[/\{/' ${DEST_FILE}
sed -i 's/\]/\}/' ${DEST_FILE}

