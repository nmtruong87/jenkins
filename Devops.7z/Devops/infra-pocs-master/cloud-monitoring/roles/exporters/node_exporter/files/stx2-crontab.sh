#!/bin/bash

OUTPUT=$(/usr/lib/check_mk_agent/local/stx2-crontab | grep OK)
check=$?
if [ $check == "0" ] ; then
  echo 'stx2_crontab{exporter="node_exporter"} 0' > /var/lib/node_exporter/textfile_collector/stx2-crontab.prom
else
  echo 'stx2_crontab{exporter="node_exporter"} 1' > /var/lib/node_exporter/textfile_collector/stx2-crontab.prom
fi
