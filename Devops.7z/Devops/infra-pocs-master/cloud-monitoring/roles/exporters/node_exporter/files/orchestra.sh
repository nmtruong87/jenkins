#!/bin/bash

OUTPUT=$(/usr/lib/check_mk_agent/local/secutix2-orchestra-isalive | grep OK)
check=$?
if [ $check == "0" ] ; then
  echo 'orchestra_is_alive{exporter="node_exporter"} 0' > /var/lib/node_exporter/textfile_collector/orchestra-isalive.prom
else
  echo 'orchestra_is_alive{exporter="node_exporter"} 1' > /var/lib/node_exporter/textfile_collector/orchestra-isalive.prom
fi

OUTPUT=$(/usr/lib/check_mk_agent/local/secutix2-orchestra-check | grep OK)
check=$?
if [ $check == "0" ] ; then
  echo 'orchestra_check{exporter="node_exporter"} 0' > /var/lib/node_exporter/textfile_collector/orchestra-check.prom
else
  echo 'orchestra_check{exporter="node_exporter"} 1' > /var/lib/node_exporter/textfile_collector/orchestra-check.prom
fi