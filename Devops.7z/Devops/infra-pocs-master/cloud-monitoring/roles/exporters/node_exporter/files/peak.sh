#!/bin/bash

OUTPUT=$(/usr/lib/check_mk_agent/local/stx-java-activity | grep ok)
check=$?
if [ $check == "0" ] ; then
  echo 'java_gc{exporter="node_exporter"} 0' > /var/lib/node_exporter/textfile_collector/peak-protect.prom
else
  echo 'java_gc{exporter="node_exporter"} 1' > /var/lib/node_exporter/textfile_collector/peak-protect.prom
fi

OUTPUT=$(/usr/lib/check_mk_agent/local/secutix2-checks | grep "ismonitorup - OK")
check=$?
if [ $check == "0" ] ; then
  echo 'pkp_is_monitor_up{exporter="node_exporter"} 0' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
else
  echo 'pkp_is_monitor_up{exporter="node_exporter"} 1' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
fi

OUTPUT=$(/usr/lib/check_mk_agent/local/secutix2-checks | grep "iscleanupthreadrunning - OK")
check=$?
if [ $check == "0" ] ; then
  echo 'pkp_is_cleanup_thread_running{exporter="node_exporter"} 0' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
else
  echo 'pkp_is_cleanup_thread_running{exporter="node_exporter"} 1' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
fi

OUTPUT=$(/usr/lib/check_mk_agent/local/secutix2-checks | grep "issyncthreadrunning - OK")
check=$?
if [ $check == "0" ] ; then
  echo 'pkp_is_sync_thread_running{exporter="node_exporter"} 0' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
else
  echo 'pkp_is_sync_thread_running{exporter="node_exporter"} 1' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
fi

OUTPUT=$(/usr/lib/check_mk_agent/local/secutix2-checks | grep "stx2-application - OK")
check=$?
if [ $check == "0" ] ; then
  echo 'pkp_stx_application{exporter="node_exporter"} 0' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
else
  echo 'pkp_stx_application{exporter="node_exporter"} 1' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
fi

OUTPUT=$(/usr/lib/check_mk_agent/local/secutix2-checks | grep "pkpmonitor-isdbconnected - OK")
check=$?
if [ $check == "0" ] ; then
  echo 'pkp_isdbconnected{exporter="node_exporter"} 0' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
else
  echo 'pkp_isdbconnected{exporter="node_exporter"} 1' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
fi

OUTPUT=$(/usr/lib/check_mk_agent/local/secutix2-checks | grep "pkpmonitor-ispurgeok - OK")
check=$?
if [ $check == "0" ] ; then
  echo 'pkp_ispurgeok{exporter="node_exporter"} 0' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
else
  echo 'pkp_ispurgeok{exporter="node_exporter"} 1' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
fi

OUTPUT=$(/usr/lib/check_mk_agent/local/bridge | grep "sys_puppet - OK |sys_puppet - WARNING")
check=$?
if [ $check == "0" ] ; then
  echo 'sys_puppet{exporter="node_exporter"} 0' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
else
  echo 'sys_puppet{exporter="node_exporter"} 1' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
fi

OUTPUT=$(/usr/lib/check_mk_agent/local/bridge | grep " sys_process_zombie - PROCS OK")
check=$?
if [ $check == "0" ] ; then
  echo 'sys_process_zombie{exporter="node_exporter"} 0' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
else
  echo 'sys_process_zombie{exporter="node_exporter"} 1' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
fi

OUTPUT=$(/usr/lib/check_mk_agent/local/bridge | grep " sys_process_running - PROCS OK")
check=$?
if [ $check == "0" ] ; then
  echo 'sys_process_running{exporter="node_exporter"} 0' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
else
  echo 'sys_process_running{exporter="node_exporter"} 1' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
fi

OUTPUT=$(/usr/lib/check_mk_agent/local/bridge | grep " sys_users - USERS OK")
check=$?
if [ $check == "0" ] ; then
  echo 'pkp_sys_users{exporter="node_exporter"} 0' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
else
  echo 'pkp_sys_users{exporter="node_exporter"} 1' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
fi

OUTPUT=$(/usr/lib/check_mk_agent/local/bridge | grep " sys_vm_sanity - Sanity check OK")
check=$?
if [ $check == "0" ] ; then
  echo 'pkp_sys_vm_sanity{exporter="node_exporter"} 0' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
else
  echo 'pkp_sys_vm_sanity{exporter="node_exporter"} 1' >> /var/lib/node_exporter/textfile_collector/peak-protect.prom
fi