#!/bin/bash

STATUS=$(systemctl status protectnfs 2>/dev/null)
checkStatus=$?
OUTPUT=$(echo $STATUS | egrep -i 'NFS.*failed')
checkOutput=$?

if [ $checkStatus -gt 0 -o $checkOutput -eq 0 ] ; then
  echo 'protectnfs_check{exporter="node_exporter"} 1' > {{ textfile_collector_path }}/protectnfs-check.prom
else
  echo 'protectnfs_check{exporter="node_exporter"} 0' > {{ textfile_collector_path }}/protectnfs-check.prom
fi

exit 0