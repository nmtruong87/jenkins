#!/bin/bash

FILE=$(ls /var/log/tomcat[7-9]/turnstileStatus.txt)
while read -r line;
do
 if [[ $line =~ "OFFLINE" ]]; then
  echo $line | awk '{ print "turnstile_status_info{line=""\""$2"\""",status=""\""$3"\"""} 1" }';
 elif [[ $line =~ "ONLINE"  ]]; then
  echo $line | awk '{ print "turnstile_status_info{line=""\""$2"\""",status=""\""$3"\"""} 0" }';
 fi
done < $FILE