#!/usr/bin/python
import boto3
import os
import socket
import datetime
from time import gmtime, strftime
import pytz
import re


# https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Overview.DBInstance.Status.html
CRIT_STT = [
    "failed", "stopped", "stopping", "storage-full", "restore-error", "rebooting",
    "incompatible-network", "incompatible-option-group", "incompatible-parameters",
    "incompatible-restore", "inaccessible-encryption-credentials"
    ]
# Variables
REGION = 'None'
fulldomainname = socket.getfqdn()
site = fulldomainname.split('.')[1]  # Get site

# Get region
if site == "usea":
    REGION = "us-east-1"
    TZ = pytz.timezone('Etc/GMT-5')
elif site == "euce":
    REGION = "eu-central-1"
    TZ = pytz.timezone('Etc/GMT+0')
elif site == "pci":
    REGION = "eu-central-1"
    TZ = pytz.timezone('Etc/GMT+0')
elif site == "euwe":
    REGION = "eu-west-1"
    TZ = pytz.timezone('Etc/GMT+0')
else:
    exit()

# Connect API
cloudwatch = boto3.client('cloudwatch', region_name=REGION)
rds = boto3.client('rds', region_name=REGION)

# Get Free Storage
def get_free_storage(dbID, metricName):
    response = cloudwatch.get_metric_statistics(
        Namespace="AWS/RDS",
        Period=300,
        MetricName=metricName,
        Dimensions=[{
            "Name": "DBInstanceIdentifier",
            "Value": dbID
        }],
        Statistics=["Average"],
        StartTime=datetime.datetime.now(TZ) - datetime.timedelta(minutes=5),
        EndTime=datetime.datetime.now(TZ),
    )
    free_kb = response['Datapoints'][0]['Average']
    return free_kb/(1024*1024*1024)

# Get Burst Balance
def get_burst_balance(dbID):
    response = cloudwatch.get_metric_statistics(
        Namespace="AWS/RDS",
        Period=300,
        MetricName="BurstBalance",
        Dimensions=[{
            "Name": "DBInstanceIdentifier",
            "Value": dbID
        }],
        Statistics=["Average"],
        StartTime=datetime.datetime.now(TZ) - datetime.timedelta(minutes=5),
        EndTime=datetime.datetime.now(TZ),
    )
    return response['Datapoints'][0]['Average']

# RDS alive monitor
#def alive(dbID, isSTT, engine):
#    if isSTT in CRIT_STT:
#        print("2 RDS_{}_isalive - Status: {}, engine: {}.".format(dbID, isSTT, engine))
#        return 1
#    else:
#        print("0 RDS_{}_isalive - Status: {}, engine: {}.".format(dbID, isSTT, engine))
#        return 0

# RDS Aurora free disk monitor
#def aurora_free(dbID, free):
#    free = round(free, 2)
#    metric = "RDS_{}_storage - Automatic storage adjustment - Free Storage Space = {}GB".format(
#        dbID, free)
#    print("0 {}".format(metric))

# RDS disk used monitor
def rds_used(dbID, used, allocated):
    used = round(used, 2)
    percent = round((used/allocated) * 100, 2)
    free = round(allocated-used,2)
    #warn = round((0.85 * allocated), 2)
    #crit = round((0.9 * allocated), 2)
    #metric = "RDS_{}_storage UsedStorageSpace={};{};{};0;{} Used Storage: {}GB of {}GB ({}%)".format(
    metric1 = "[type=\"oracle-rds\", db=\"{}\", metric=\"UsedSpace\"] {}".format(dbID, used)
    metric2 = "[type=\"oracle-rds\", db=\"{}\", metric=\"FreeSpace\"] {}".format(dbID, free)
    metric3 = "[type=\"oracle-rds\", db=\"{}\", metric=\"PctUsedSpace\"] {}".format(dbID, percent)
    print("database_check{}".format(metric1))
    print("database_check{}".format(metric2))
    print("database_check{}".format(metric3))

def burstbalance_usage(dbID, current_usage):
    current_usage = round(current_usage, 2)
    metric = "[type=\"oracle-rds\", db=\"{}\", metric=\"BurstBalance\"] {}".format(dbID, current_usage)
    print("database_check{}".format(metric))


#example prometheus output:
# database_check{type="oracle-rds", db="t28oracle1", metric="BurstBalance"} 99.0

# Output for Check MK
def monitor():
  for db in rds.describe_db_instances()['DBInstances']:
    dbID = db['DBInstanceIdentifier']
    isSTT = db['DBInstanceStatus']
    engine = db['Engine']
    if re.search("aurora", db['Engine']):
        # we will not monitoring disk in aurora
        continue
    else:
        # Alive monitor
        #stt = alive(dbID, isSTT, engine)
        #if stt == 1:
        #    print(
        #        "1 RDS_{}_storage - Not checking free storage, DB status: {}".format(dbID, isSTT))
        #    continue
        metricName = 'FreeStorageSpace'
        free = get_free_storage(dbID, metricName)
        allocated = db['AllocatedStorage']
        used = allocated - free
        rds_used(dbID, used, allocated)
        current_usage = get_burst_balance(dbID)
        burstbalance_usage(dbID, current_usage)
monitor()
