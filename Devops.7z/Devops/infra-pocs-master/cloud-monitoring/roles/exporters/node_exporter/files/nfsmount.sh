#!/bin/sh

/usr/bin/perl {{ node_exporter_lib_path }}/sys-nfsmount > /var/lib/node_exporter/textfile_collector/nfsmount.prom 2>/dev/null

exit 0
