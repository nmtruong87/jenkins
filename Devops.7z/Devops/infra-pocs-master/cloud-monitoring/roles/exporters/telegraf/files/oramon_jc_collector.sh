#!/bin/bash
#-----------------------------------------------------#
# Oracle Environment Variables
#-----------------------------------------------------#
export ORACLE_HOME=/usr/lib/oracle/19.8/client64
export LD_LIBRARY_PATH=$ORACLE_HOME/lib
export TNS_ADMIN=$ORACLE_HOME/network/admin
#-----------------------------------------------------#
# Internal variables
#-----------------------------------------------------#
orapwd=`fgrep ${1} $(dirname $0)/.orapasswd | cut -d " " -f2`
filedb=$(dirname $0)/.dblist${1}
declare -a db
db=(`cat "$filedb" | xargs`)
declare -a dbenv
dbenv=(`cat "$filedb" | grep -Po "^\D*" | xargs`)
# ----------------------------------------------------#
# Getting Stats from the Databases
#-----------------------------------------------------#
for (( i = 0 ; i < ${#db[@]} ; i++))
do
    python3 "/etc/telegraf/oracle/oramon_jc_collector.py" ALL "-u" "monitor" "-p" ${orapwd} "-s" ${db[$i]} "-e" ${dbenv[$i]}
done
#------------------- End script ----------------------#
