import socket
import argparse
import subprocess
import re
import cx_Oracle

fqdn = socket.getfqdn()

class OraStats():

    def __init__(self, user, passwd, sid, env):
        self.user = user
        self.passwd = passwd
        self.sid = sid
        self.env = env
        self.connection = cx_Oracle.connect(self.user, self.passwd, self.sid)
        ##cursor = self.connection.cursor()
        ##cursor.execute("select distinct(SVRNAME)  from v$dnfs_servers")
        ##rows = cursor.fetchall()

    def waitclassstats(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        select n.wait_class, round(m.time_waited/m.INTSIZE_CSEC,3) AAS
        from   v$waitclassmetric  m, v$system_wait_class n
        where m.wait_class_id=n.wait_class_id and n.wait_class != 'Idle'
        union
        select  'CPU', round(value/100,3) AAS
        from v$sysmetric where metric_name='CPU Usage Per Sec' and group_id=2
        union select 'CPU_OS', round((prcnt.busy*parameter.cpu_count)/100,3) - aas.cpu
        from
        ( select value busy
        from v$sysmetric
        where metric_name='Host CPU Utilization (%)'
         and group_id=2 ) prcnt,
        ( select value cpu_count from v$parameter where name='cpu_count' )  parameter,
        ( select  'CPU', round(value/100,3) cpu from v$sysmetric where metric_name='CPU Usage Per Sec' and group_id=2) aas
        """)
        for wait in cursor:
            wait_name = wait[0]
            wait_value = wait[1]
            print ("oracle_wait_class,fqdn={0},env={1},db={2},wait_class={3} wait_value={4}".format(fqdn, self.env, sid, re.sub(' ', '_', wait_name), wait_value))


    def sysmetrics(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        select METRIC_NAME,VALUE,METRIC_UNIT from v$sysmetric where group_id=2
        """)
        for metric in cursor:
            metric_name = metric[0]
            metric_value = metric[1]
            print ("oracle_sysmetric,fqdn={0},env={1},db={2},metric_name={3} metric_value={4}".format(fqdn,self.env,sid,re.sub(' ', '_', metric_name),metric_value))

    def fraused(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        select round((SPACE_USED-SPACE_RECLAIMABLE)*100/SPACE_LIMIT,1) from  V$RECOVERY_FILE_DEST
        """)
        for frau in cursor:
            fra_used = frau[0]
            print ("oracle_fra_pctused,fqdn={0},env={1},db={2} fra_pctused={3}".format(fqdn,self.env,sid,fra_used))

    def fsused(self):
     fss = ['/oracle', '/data']
     for fs in fss:
            df = subprocess.Popen(["df","-P",fs], stdout=subprocess.PIPE)
            output = df.communicate()[0]
            total=re.sub('%','',output.split("\n")[1].split()[1])
            used=re.sub('%','',output.split("\n")[1].split()[2])
            pctused=re.sub('%','',output.split("\n")[1].split()[4])
            print ("oracle_fs_pctused,fqdn={0},fs_name={1} oraclefs_pctused={2},oraclefs_alloc={3},oraclefs_used={4}".format(fqdn,fs,pctused,total,used))

    def waitstats(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        select /*+ ordered use_hash(n) */
        n.wait_class wait_class,
        n.name wait_name,
        m.wait_count  cnt,
        nvl(round(10*m.time_waited/nullif(m.wait_count,0),3) ,0) avg_ms
        from v$eventmetric m,
        v$event_name n
        where m.event_id=n.event_id
        and n.wait_class <> 'Idle' and m.wait_count > 0 order by 1""")
        for wait in cursor:
            wait_class = wait[0]
            wait_name = wait[1]
            wait_cnt = wait[2]
            wait_avgms = wait[3]
            print ("oracle_wait_event,fqdn={0},env={1},db={2},wait_class={3},wait_event={4} count={5},latency={6}".format(fqdn, self.env,sid,re.sub(' ', '_', wait_class), re.sub(' ','_',wait_name),wait_cnt,wait_avgms))

    def tbsstats(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        select /*+ ordered */ tablespace_name,
            round(used_space),
            round(max_size-used_space) free_space,
            round(max_size),
            round(used_space*100/max_size,2) percent_used
            from (
                select m.tablespace_name,
                m.used_space*t.block_size/1024/1024 used_space,
                (case when t.bigfile='YES' then power(2,32)*t.block_size/1024/1024
                        else tablespace_size*t.block_size/1024/1024 end) max_size
            from dba_tablespace_usage_metrics m, dba_tablespaces t
        where m.tablespace_name=t.tablespace_name)
        """)
        for tbs in cursor:
            tbs_name = tbs[0]
            used_space_mb = tbs[1]
            free_space_mb = tbs[2]
            max_size_mb = tbs[3]
            percent_used = tbs[4]
            print ("oracle_tablespaces,fqdn={0},env={1},db={2},tbs_name={3} used_space_mb={4},free_space_mb={5},percent_used={6},max_size_mb={7}".format(fqdn, self.env, sid, re.sub(' ', '_', tbs_name), used_space_mb,free_space_mb,percent_used,max_size_mb))

    def pgastat(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        select name pga_name, round(value/power(1024,2),2) pga_value FROM V$PGASTAT WHERE NAME IN ('aggregate PGA target parameter','total PGA allocated','total PGA inuse')
        UNION
        select name pga_name, value pga_value from V$PGASTAT WHERE name in ('over allocation count')
        """)
        for pgastat in cursor:
            pga_name = pgastat[0]
            pga_value = pgastat[1]
            print ("oracle_pga_status,fqdn={0},env={1},db={2},pga_name={3} pga_value={4} ".format(fqdn,self.env,sid,re.sub(' ', '_', pga_name),pga_value))

    def sgastat(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
                select nvl(pool,'buffer cache') sga_pool, round(sum(bytes/power(1024,2)),2) pool_size from v$sgastat group by pool
        """)
        for sgastat in cursor:
            sga_pool = sgastat[0]
            pool_size = sgastat[1]
            print ("oracle_sga_status,fqdn={0},env={1},db={2},sga_pool={3} pool_size={4} ".format(fqdn,self.env,sid,re.sub(' ', '_', sga_pool),pool_size))

    def sharedstat(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        SELECT name, round(sum(bytes/(1024*1024))) MB
		FROM   v$sgastat
		WHERE  pool = 'shared pool'
		group by name
		having sum(bytes/(1024*1024)) > 500
		UNION ALL
		select 'Others' name, round(sum(bytes/(1024*1024))) MB
		FROM   v$sgastat
		WHERE  pool = 'shared pool'
		and (bytes/(1024*1024)) < 500
        """)
        for sharedstat in cursor:
            sha_pool = sharedstat[0]
            pool_size = sharedstat[1]
            print ("oracle_shared_status,fqdn={0},env={1},db={2},sha_pool={3} pool_size={4} ".format(fqdn,self.env,sid,re.sub(' ', '_', sha_pool),pool_size))

    def locks(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        select /*+ ORDERED */
            count(s.sid) locked_sess
        from v$lock l, v$session s, v$lock l2, v$session s2
        where l.request <> 0
            and s.sid = l.sid
            and l2.id1 = l.id1
            and l2.id2 = l.id2
            and l2.request = 0
            and s2.sid = l2.sid
            and l.ctime > 30
        """)
        for locks in cursor:
            lock_cnt = locks[0]
            print ("oracle_block_cnt,fqdn={0},env={1},db={2} lock_cnt={3} ".format(fqdn,self.env,sid,lock_cnt))

    def topsqlid(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
		select * from (
			select
				 ash.SQL_ID , ash.SQL_PLAN_HASH_VALUE, '"'||aud.name||'"' oper,
				 sum(decode(ash.session_state,'ON CPU',1,0)) as CPU,
				 sum(decode(ash.session_state,'WAITING',1,0)) - sum(decode(ash.session_state,'WAITING', decode(ash.wait_class, 'User I/O',1,0),0)) as WAIT,
				 sum(decode(ash.session_state,'WAITING', decode(ash.wait_class, 'User I/O',1,0),0)) as IO,
				 sum(decode(ash.session_state,'ON CPU',1,1)) as TOTAL,
				 count(distinct session_id) dist_sess, '"'||nvl(event,'CPU')||'"' event
			from v$active_session_history ash, audit_actions aud
			where ash.SQL_ID is not NULL
			and ash.sql_opcode=aud.action
			and ash.SAMPLE_TIME > (sysdate-60/(3600*24))
			group by ash.sql_id, ash.SQL_PLAN_HASH_VALUE, aud.name, event
			order by sum(decode(ash.session_state,'ON CPU',1,1))   desc
			)
		where rownum <11
        """)
        for tsi in cursor:
            sql_id = tsi[0]
            sql_plan_hash_value = tsi[1]
            oper = tsi[2]
            cpu = tsi[3]
            wait = tsi[4]
            io = tsi[5]
            total = tsi[6]
            dsess = tsi[7]
            event = tsi[8]
            print ("oracle_top_sqls,fqdn={0},env={1},db={2},sql_id={3} sql_plan_hash_value={4},oper={5},cpu={6},wait={7},io={8},total={9},dsess={10},event={11}".format(fqdn,self.env,sid,sql_id,sql_plan_hash_value,oper,cpu,wait,io,total,dsess,re.sub(' ', '_',event)))

    def timemodel(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        select stat_name, trunc(value/1000000) seconds from v$sys_time_model
        """)
        for metric in cursor:
            stat_name = metric[0]
            stat_value = metric[1]
            print ("oracle_timemodel,fqdn={0},env={1},db={2},stat_name={3} stat_value={4}".format(fqdn,self.env,sid,re.sub(' ', '_', stat_name),stat_value))

    def rscmgr(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        select consumer_group_name,
               cpu_consumed_time,
               cpu_wait_time,
               num_cpus,
               avg_running_sessions,
               avg_waiting_sessions,
               avg_cpu_utilization,
               io_requests,
               io_megabytes
        from   v$rsrcmgrmetric
        where  cpu_consumed_time > 0
        """)
        for rscmgr in cursor:
            rs_cgnam = rscmgr[0]
            rs_conti = rscmgr[1]
            rs_cpuwt = rscmgr[2]
            rs_ncpus = rscmgr[3]
            rs_avgrs = rscmgr[4]
            rs_avgws = rscmgr[5]
            rs_avgcu = rscmgr[6]
            rs_ioreq = rscmgr[7]
            rs_iombs = rscmgr[8]
            print ("oracle_rscmgr,fqdn={0},env={1},db={2},rs_cgnam={3} rs_conti={4},rs_cpuwt={5},rs_ncpus={6},rs_avgrs={7},rs_avgws={8},rs_avgcu={9},rs_ioreq={10},rs_iombs={11} ".format(fqdn,self.env,sid,re.sub(' ', '_', rs_cgnam),rs_conti,rs_cpuwt,rs_ncpus,rs_avgrs,rs_avgws,rs_avgcu,rs_ioreq,rs_iombs))

    def uptime(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        select 'uptime' uptime,round((sysdate-startup_time)*(86400),0) startup_time from v$instance
        """)
        for uptime in cursor:
            up_name = uptime[0]
            up_value = uptime[1]
            print ("oracle_uptime,fqdn={0},env={1},db={2},sp_name={3} sp_value={4} ".format(fqdn,self.env,sid,up_name,up_value))

    def filestats(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        select 'filestats' filestats,a.datafiles, a.dbsize,b.value                                                       
        from 
        (select count(1) datafiles ,sum(bytes) dbsize from v$datafile) a,
        (select value from v$parameter where name='db_files') b
        """)
        for filestats in cursor:
            fs_name = filestats[0]
            fs_ndfl = filestats[1]
            fs_dbsz = filestats[2]
            fs_mxdf = filestats[3]
            print ("oracle_filestats,fqdn={0},env={1},db={2},fs_name={3} fs_ndfl={4},fs_dbsz={5},fs_mxdf={6} ".format(fqdn,self.env,sid,fs_name,fs_ndfl,fs_dbsz,fs_mxdf))

    def stxsessions(self, user, passwd, sid, format, env):
        cursor = self.connection.cursor()
        cursor.execute("""
        select username, count(1) as TotalConn,
        sum(case when last_call_et = 0 then 1 else 0 end) WorkingSessions,
        sum(case when last_call_et between 1 and 60 then 1 else 0 end) Idle_less_1_min,
        sum(case when last_call_et between 61 and 300 then 1 else 0 end) as Idle_less_5_min,
        sum(case when last_call_et between 301 and 600 then 1 else 0 end) as Idle_less_10_min,
        sum(case when last_call_et between 601 and 900 then 1 else 0 end) Idle_Less_15_min,
        sum(case when last_call_et > 901 then 1 else 0 end) Idle_Less_20_min,
        round(max(last_call_et)/60,0) MaxIdleTime
        FROM v$session
        WHERE username in ('STXBIL_ORCHESTRA','STXBIL_APPL','STXBIL_ACCESS')--and machine like 'app%'
        group by username
        """)
        for stxsessions in cursor:
            stxsess_usu = stxsessions[0]
            stxsess_tot = stxsessions[1]
            stxsess_wse = stxsessions[2]
            stxsess_i01 = stxsessions[3]
            stxsess_i05 = stxsessions[4]
            stxsess_i10 = stxsessions[5]
            stxsess_i15 = stxsessions[6]
            stxsess_i20 = stxsessions[7]
            stxsess_mxi = stxsessions[8]
            print ("capacity_stx_sess,fqdn={0},env={1},db={2},stxsess_usu={3} stxsess_tot={4},stxsess_wse={5},stxsess_i01={6},stxsess_i05={7},stxsess_i10={8},stxsess_i15={9},stxsess_i20={10},stxsess_mxi={11} ".format(fqdn,self.env,sid,stxsess_usu,stxsess_tot,stxsess_wse,stxsess_i01,stxsess_i05,stxsess_i10,stxsess_i15,stxsess_i20,stxsess_mxi))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--format', help="Output format, default influx", choices=['kafka', 'influx'], default='influx')
    subparsers = parser.add_subparsers(dest='stat')
    parser_all = subparsers.add_parser('ALL', help="Get all database stats")
    parser_all.add_argument('-u', '--user', help="Username with limited views grant", required=True)
    parser_all.add_argument('-p', '--passwd', required=True)
    parser_all.add_argument('-s', '--sid', help="tnsnames SID to connect", required=True)
    parser_all.add_argument('-e', '--env', help="environment to connect", required=True)

    args = parser.parse_args()

    if args.stat == "ALL":
        stats = OraStats(args.user, args.passwd, args.sid, args.env)
        stats.waitclassstats(args.user, args.passwd, args.sid, args.format, args.env)
        stats.waitstats(args.user, args.passwd, args.sid, args.format, args.env)
        stats.sysmetrics(args.user, args.passwd, args.sid, args.format, args.env)
        stats.timemodel(args.user, args.passwd, args.sid, args.format, args.env)
        stats.tbsstats(args.user, args.passwd, args.sid, args.format, args.env)
#        stats.fraused(args.user, args.passwd, args.sid, args.format)
        stats.pgastat(args.user, args.passwd, args.sid, args.format, args.env)
        stats.sgastat(args.user, args.passwd, args.sid, args.format, args.env)
        stats.sharedstat(args.user, args.passwd, args.sid, args.format, args.env)
        stats.locks(args.user, args.passwd, args.sid, args.format, args.env)
        stats.rscmgr(args.user, args.passwd, args.sid, args.format, args.env)  
        stats.uptime(args.user, args.passwd, args.sid, args.format, args.env)
        stats.filestats(args.user, args.passwd, args.sid, args.format, args.env)  
        stats.stxsessions(args.user, args.passwd, args.sid, args.format, args.env)   
#        stats.topsqlid(args.user, args.passwd, args.sid, args.format, args.env)
        #stats.fsused()
