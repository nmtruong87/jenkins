#! /bin/bash

# Use config server and sharky name
export CFG_SRV_HOST="${ENV}-config-server.${SITE}.secutix.net"
ENV_CONF=`curl -s http://$CFG_SRV_HOST/ticketing/$ENV`

# Select InfluxDB host
case $SITE in
    hrp)
      export INFLUX_DB="cs1cloudmon1a.hrp.secutix.net"
      ;;
    seb)
      export INFLUX_DB="p1cloudmon1a.seb.secutix.net"
      ;;
    gva)
      export INFLUX_DB="p1cloudmon1a.gva.secutix.net"
      ;;
    sgn)
      export INFLUX_DB="cs1cloudmon1a.sgn.secutix.net"
      ;;
    euce)
      export INFLUX_DB="p1cloudmon1a.seb.secutix.net"
      ;;
    usea)
      export INFLUX_DB="p1cloudmon1a.seb.secutix.net"
      ;;
esac

# Get MongoDB parameters
export MONGODB_HOST=`echo $ENV_CONF | jq -r '."'frontend.mongodb.replicaset.seeds'"' | cut -d':' -f1`".$SITE.secutix.net"
export MONGODB_USR=`echo $ENV_CONF | jq -r '."'frontend.mongodb.username'"'`
export MONGODB_PASSWORD=`echo $ENV_CONF | jq -r '."'frontend.mongodb.password'"'`

# Check sharky components
COMPONENTS=("`echo $ENV_CONF | jq -r '."'sharky.components'"'`")
for c in $COMPONENTS;
do
    c_name=`echo $c | cut -d':' -f1`
    # if [ "$c_name" == "squid" ]; then
    #     export SQUID_HOST=`echo $ENV_CONF | jq -r '."'env.proxy.host'"'`".$SITE.secutix.net" # Get Squid Proxy hostname
    #     #prometheus-squid-exporter -squid-hostname $SQUID_HOST -squid-port 3129 & # Run Squid exporter
    #     squid-exporter -squid-hostname $SQUID_HOST -squid-port 3129 -listen ":14010" & # Run Squid exporter
    # fi
    if [ "$c_name" == "activemq" ]; then
        export ACTIVEMQ_HOST=`echo $ENV_CONF | jq -r '."'jms.internal.host'"'`".$SITE.secutix.net" # Get Squid Proxy hostname
        telegraf & # Run Telegraf for ActiveMQ
    fi
done

# Initiate MongoDB exporter
mongodb_exporter --web.listen-address=":14216" --mongodb.uri mongodb://$MONGODB_USR:$MONGODB_PASSWORD@$MONGODB_HOST:27017/admin &

# Initiate cAdvisor
cadvisor --port 14323
