#!/bin/bash

DOCKER_NAME="exporters" # secutix/<Docker_Name> 

dieIfNotNull() {
	RETVAL=$?
	if [ $RETVAL != "0" ]; then
		echo "[FAILED] see console for more information"
		exit $RETVAL
	fi
}

# sharky-exporters docker image
docker build -f Dockerfile -t secutix/${DOCKER_NAME}:${BUILD_NUMBER} .
dieIfNotNull $?

ECR_REG_ADDRESS="851772184252.dkr.ecr.eu-west-1.amazonaws.com"
docker tag secutix/${DOCKER_NAME}:${BUILD_NUMBER} ${ECR_REG_ADDRESS}/secutix/${DOCKER_NAME}:${BUILD_NUMBER}
dieIfNotNull $?

docker tag secutix/${DOCKER_NAME}:${BUILD_NUMBER} ${ECR_REG_ADDRESS}/secutix/${DOCKER_NAME}:dev
dieIfNotNull $?

echo "Push image to ECR"
docker push ${ECR_REG_ADDRESS}/secutix/${DOCKER_NAME}:${BUILD_NUMBER}
dieIfNotNull $?

docker push ${ECR_REG_ADDRESS}/secutix/${DOCKER_NAME}:dev
dieIfNotNull $?
