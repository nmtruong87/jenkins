# Sharky Exporters

This folder containes the necessary files to build a docker container where all the exporters needed to monitor the sharky containers will be installed. This container is composed by the following exporters:

- ActiveMQ exporter based in Telegraf
- cAdvisor for container health monitoring
- MongoDB exporter for Prometheus
- Squid exporter for prometheus

### How to run the container:

```shell
docker run -d \
-p 14323:8080 \
-p 14010:9301 \
-p 14216:9001 \
--name ce-sharky-mon \
-e ENV=val0 \
-e SITE=HRP \
-v /etc/timezone:/etc/timezone:ro \
-v /etc/localtime:/etc/localtime:ro \
-v=/:/rootfs:ro \
-v=/var/run:/var/run:rw \
-v=/sys:/sys:ro \
-v=/var/lib/docker/:/var/lib/docker:ro \
 sharky-exporters
```