#!/bin/bash
#
# Goal   : Verify that all needed components are running
# Author : JCB - 11.05.2020

export HTTPS_PROXY=http://proxy:3128

ECR_REPO_PREFIX="851772184252.dkr.ecr.eu-west-1.amazonaws.com/secutix"

LOG_FILE=/var/log/sharky/sharky.log
ENV=`uname -n | sed -e 's/\(^[a-z]*[0-9]*\).*/\1/g'`
SITE=`hostname -f | cut -d . -f 2`

. /usr/share/sharky/functions.sh

function log(){
  MSG=$1
  if [ -t 1 ]; then
    echo `date` $MSG
    echo `date` $MSG >> $LOG_FILE
  else
    echo `date` $MSG >> $LOG_FILE
  fi
}

log "[INFO] Getting components list for environment $ENV..."
COMPONENTS=$(get_config sharky.components)
if [ -z "$COMPONENTS" ]; then
  log "[INFO] No components found in config. Running config-server only."
  COMPONENTS="config-server:prod"
fi

#COMPONENTS="letsencrypt:5"
log "[INFO] Components list : $COMPONENTS"
log "[INFO] Logging in AWS ECR..."
ECR_LOGIN_STRING=`aws ecr get-login --region eu-west-1 --profile sharky --no-include-email`
eval ${ECR_LOGIN_STRING} > /dev/null 2>&1
dieIfNotNull $?
log "[INFO] Done."

for c in $COMPONENTS; do
  COMP=`echo $c | cut -d':' -f1`
  TAG=`echo $c | cut -d':' -f2`
  log "[INFO] Working on '$COMP', tag '$TAG'"
  REPOSITORY=${ECR_REPO_PREFIX}/$COMP

  # Get current image digest
  #CUR_DIGEST=`docker images $REPOSITORY --format "{{.Digest}}"`
  CUR_DIGEST=`docker images $REPOSITORY --digests | grep -i "$REPOSITORY \+$TAG" | grep -Eo "sha256:[0-9a-z]+"`

  # Get latest available image digest
  NEW_IMAGE=`aws ecr describe-images --region eu-west-1 --profile sharky --repository-name secutix/$COMP --image-ids imageTag=$TAG`
  dieIfNotNull $?
  NEW_DIGEST=`echo $NEW_IMAGE | jq '.imageDetails[0] .imageDigest' | sed 's/"//g'`

  # If new image -> replace
  if [ "$CUR_DIGEST" == "$NEW_DIGEST" ]; then
    log "[INFO] Image already up to date."
  else
    log "[INFO] Updating image for $COMP:$TAG"
    docker pull $REPOSITORY:$TAG
    NB_RUNNING=`docker ps --filter "name=^$COMP$" --format "{{.Image}}" | wc -l`
    if [ "$NB_RUNNING" -eq "1" ]; then
      log "[INFO] Stopping old running container..."
      log `docker stop $COMP`
      log `docker rm $COMP`
    fi
  fi

  # Verify only one image is running
  log "[INFO] Ensure that one container running '$COMP:$TAG' is running."
  NB_RUNNING=`docker ps --filter "name=^$COMP$" --format "{{.Image}}" | wc -l`
  if [ "$NB_RUNNING" -eq "0" ]; then
    if [ "$COMP" -eq "exporters" ]; then
      LISTEN_PORT="-p 14323:8080 -p 14010:9301 -p 14216:9001"
      HEALTH_PORT="-p 14323:8080 -p 14010:9301 -p 14216:9001"
    else
      LISTEN_PORT=`get_port $COMP`
      HEALTH_PORT=$((LISTEN_PORT+1))
    fi
    NB_STOPPED=`docker ps -a --filter "name=^$COMP$" --format "{{.Image}}" | wc -l`
    if [ "$NB_STOPPED" -eq "1" ]; then
      log "[INFO] Stopped container found Trying to start it..."
      log `docker start $COMP`
      log "[INFO] Sleeping 10 seconds for letting $COMP start..."
      sleep 10
      NB_RUNNING=`docker ps --filter "name=^$COMP$" --format "{{.Image}}" | wc -l`
      if [ "$NB_RUNNING" -eq "0" ]; then
        log "[INFO] Failed to start. Recreate it..."
        log `docker rm $COMP`
        if [ "$COMP" -eq "exporters" ]; then
          log `docker run --name $COMP --restart always -v /etc/timezone:/etc/timezone:ro -v /etc/localtime:/etc/localtime:ro -v /:/rootfs:ro -v /var/run:/var/run:rw -v /sys:/sys:ro -v /var/lib/docker/:/var/lib/docker:ro -e ENV=$ENV -e SITE=$SITE $LISTEN_PORT -d $REPOSITORY:$TAG`
        else
          log `docker run --name $COMP --restart always -v /etc/timezone:/etc/timezone:ro -v /etc/localtime:/etc/localtime:ro -e ENV=$ENV -e SITE=$SITE -e HTTP_PROXY=$HTTPS_PROXY -p $LISTEN_PORT:$LISTEN_PORT -p $HEALTH_PORT:$HEALTH_PORT -d $REPOSITORY:$TAG`
        fi
        log "[INFO] Sleeping 10 seconds for letting $COMP start..."
        sleep 10
      fi
    else
        if [ "$COMP" -eq "exporters" ]; then
          log `docker run --name $COMP --restart always -v /etc/timezone:/etc/timezone:ro -v /etc/localtime:/etc/localtime:ro -v /:/rootfs:ro -v /var/run:/var/run:rw -v /sys:/sys:ro -v /var/lib/docker/:/var/lib/docker:ro -e ENV=$ENV -e SITE=$SITE $LISTEN_PORT -d $REPOSITORY:$TAG`
        else
          log `docker run --name $COMP --restart always -v /etc/timezone:/etc/timezone:ro -v /etc/localtime:/etc/localtime:ro -e ENV=$ENV -e SITE=$SITE -e HTTP_PROXY=$HTTPS_PROXY -p $LISTEN_PORT:$LISTEN_PORT -p $HEALTH_PORT:$HEALTH_PORT -d $REPOSITORY:$TAG`
        fi
      log "[INFO] Sleeping 10 seconds for letting $COMP start..."
      sleep 10
    fi
  fi
done

log "[INFO] End."