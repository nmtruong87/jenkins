# Cloud-Monitoring

- Jira: https://jira.secutix.com/browse/ENV-11868
- Doc: https://confluence.secutix.com/display/IDOCFR/Cloud+Monitoring
