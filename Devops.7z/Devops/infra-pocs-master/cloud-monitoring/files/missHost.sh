#!/bin/bash

# Ansible managed
# awx_sites = hrp or seb
# run every day at 7 AM UTC +2 (zurich) or 12pm UTC +7 (HCM)
# The awx_api_node|process can change the id, if awx have upgrade

# Variables:
awx_sites=$1
inventory="master"

# Functions:
_missHost_setVar() {
    if [[ "$awx_sites" == "hrp" ]] ; then
        prometheus[0]="cs1cloudmon1a.sgn.secutix.net"
        prometheus[1]="cs1cloudmon1a.hrp.secutix.net"
        prometheus[2]="cs1prometheus1a.sd01.secutix.net"
        awx_api_node=13
        awx_api_process=105
        awx_api_haproxy=16
    fi
    if [[ "$awx_sites" == "seb" ]] ; then
        prometheus[0]="p1cloudmon1a.seb.secutix.net"
        prometheus[1]="p1cloudmon1a.gva.secutix.net"
        prometheus[2]="p1prometheus1a.euce.secutix.net"
        prometheus[3]="p1prometheus1a.usea.secutix.net"        
        awx_api_node=22
        awx_api_process=24
        awx_api_haproxy=21
    fi
}

_missHost_prepare() {
    curl -s "http://$prometheus_tmp:9090/api/v1/query?query=up==0" | jq -r '.data.result[].metric | "\(.job) \(.instance)"' | sort | tee /tmp/miss_host
}

_missHost_callDeployNodeExporter() {
    miss_tmp="$(cat /tmp/miss_host | grep node | grep -Po " .*net" | grep -Po "^ \w*\d" | uniq | tr -d ' ' | tr '\n' '|')"
    if [[ ! -z "$miss_tmp" ]] ; then
        tower-cli job launch --job-template="$awx_api_node" --inventory="$inventory" --extra-vars="stx_host=~'${miss_tmp::-1}'"
    fi
}

_missHost_callDeployProcessExporter() {
    miss_tmp="$(cat /tmp/miss_host | grep process | grep -Po " .*net" | grep -Po "^ \w*\d" | uniq | tr -d ' ' | tr '\n' '|')"
    if [[ ! -z "$miss_tmp" ]] ; then
        tower-cli job launch --job-template="$awx_api_process" --inventory="$inventory" --extra-vars="stx_host=~'${miss_tmp::-1}'"
    fi
}

_missHost_callDeployHaproxyExporter() {
    miss_tmp="$(cat /tmp/miss_host | grep haproxy | grep -Po " .*net" | grep -Po "^ \w*\d" | uniq | tr -d ' ' | tr '\n' '|')"
    if [[ ! -z "$miss_tmp" ]] ; then
        tower-cli job launch --job-template="$awx_api_haproxy" --inventory="$inventory" --extra-vars="stx_host=~'${miss_tmp::-1}'"
    fi
}

_missHost_run(){
    _missHost_setVar
    for (( i = 0 ; i < ${#prometheus[@]} ; i++))
    do
        prometheus_tmp="${prometheus[$i]}"
        _missHost_prepare
        _missHost_callDeployProcessExporter
        sleep 30
        _missHost_callDeployNodeExporter
        _missHost_callDeployHaproxyExporter
    done
}

# Main
_missHost_run
