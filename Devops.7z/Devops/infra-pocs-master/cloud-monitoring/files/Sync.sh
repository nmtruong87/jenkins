#!/bin/bash

awx_sites=$1
declare -a group_machine
declare -a group_env
declare -a group_delete
group_machine=(`cat /tmp/stx | sed -e 's|, |\n|g' | tr -d "[" | tr -d "]"`)
group_delete=(`cat /tmp/stx_delete | sed -e 's|, |\n|g' | tr -d "[" | tr -d "]"`)
dir=/tmp/
inventory="master"

_getHost_prepare() {
  if [[ "$awx_sites" == "hrp" ]] ; then
    data_center[0]="SGN"
    data_center[1]="HRP"
    data_center[2]="SD01"
  fi
  if [[ "$awx_sites" == "seb" ]] ; then
    data_center[0]="GVA"
    data_center[1]="SEB"
    data_center[2]="EUCE"
    data_center[3]="USEA"
    wget -q -O /tmp/ocs/SecuTix_MXP.yaml "http://ocsserver.se2.secutix.net/hosts/hosts.cgi?fqdn=true&outputFormat=rundeck&showOnly=env|type|cluster|site|parity|instances|envFamily|ServiceFor|MonitorFor|adfsFor|to_be_rebooted|sshMethod&site=mxp&domainName=mxp.secutix.net"
    cat /tmp/ocs/SecuTix_MXP.yaml >> /tmp/ocs/SecuTix_SEB.yaml
#    cat /tmp/ocs/SecuTix_EUCE.yaml >> /tmp/ocs/SecuTix_SEB.yaml
#    cat /tmp/ocs/SecuTix_USEA.yaml >> /tmp/ocs/SecuTix_SEB.yaml
  fi
  for (( i = 0 ; i < ${#data_center[@]} ; i++))
    do
      cat "$dir"ocs/SecuTix_${data_center[$i]}.yaml > "$dir"host_${data_center[$i]}
    done
  for (( j = 0 ; j < ${#group_delete[@]} ; j++))
    do
      de_tmp="$(echo "${group_delete[$j]}" | grep -Po "(.*?)(?=\#)")"
      dec_tmp="$(echo "${group_delete[$j]}" | grep -Po "(?<=\#)\w*")"
      sed -i "/$de_tmp/d" "$dir"host_"$dec_tmp"
    done
  if [[ "$awx_sites" == "hrp" ]] ; then
    printf "cs1massmail2a.hrp.secutix.net\n" >> "$dir"host_HRP
    printf "cs1massmail2b.hrp.secutix.net\n" >> "$dir"host_HRP
    printf "int0nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "int1nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "int4nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "qa10nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "qa11nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "qa20nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "qa21nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "qa30nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "val0nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "val1nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "cs1massmail2a.sgn.secutix.net\n" >> "$dir"host_SGN
    printf "cs1massmail2b.sgn.secutix.net\n" >> "$dir"host_SGN
    printf "qa22nfs8a.sg2.secutix.net\n" >> "$dir"host_SGN
    printf "int2nfs8a.sg2.secutix.net\n" >> "$dir"host_SGN
    printf "dev12nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "gam2nfs8a.sg2.secutix.net\n" >> "$dir"host_SGN
    printf "dev2nfs8a.sg2.secutix.net\n" >> "$dir"host_SGN
    printf "dev0nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "dev1nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "dev9nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
    printf "cs1nfs8a.hr2.secutix.net\n" >> "$dir"host_HRP
  fi
  if [[ "$awx_sites" == "seb" ]] ; then
    printf "p1massmail2a.seb.secutix.net\n" >> "$dir"host_SEB
    printf "p1massmail2b.seb.secutix.net\n" >> "$dir"host_SEB
    printf "p1massmail2c.seb.secutix.net\n" >> "$dir"host_SEB
    printf "p1massmail2d.seb.secutix.net\n" >> "$dir"host_SEB
    printf "p16nfs8a.se2.secutix.net\n" >> "$dir"host_SEB
    printf "p20nfs8a.se2.secutix.net\n" >> "$dir"host_SEB
    printf "p44nfs8a.se2.secutix.net\n" >> "$dir"host_SEB
    printf "p14nfs8a.se2.secutix.net\n" >> "$dir"host_SEB
    printf "p15nfs8a.se2.secutix.net\n" >> "$dir"host_SEB
    printf "dm1nfs8a.se2.secutix.net\n" >> "$dir"host_SEB
    printf "pp1nfs8a.se2.secutix.net\n" >> "$dir"host_SEB
    printf "cs1nfs8a.se2.secutix.net\n" >> "$dir"host_SEB
    printf "pp2nfs8a.se2.secutix.net\n" >> "$dir"host_SEB
    printf "p2nfs8a.se2.secutix.net\n" >> "$dir"host_SEB
    printf "p1massmail2a.gva.secutix.net\n" >> "$dir"host_GVA
    printf "p1massmail2b.gva.secutix.net\n" >> "$dir"host_GVA
    printf "p1massmail2c.gva.secutix.net\n" >> "$dir"host_GVA
    printf "p1massmail2d.gva.secutix.net\n" >> "$dir"host_GVA
    printf "perf15nfs8a.gv2.secutix.net\n" >> "$dir"host_GVA
    printf "p14nfs8a.gv2.secutix.net\n" >> "$dir"host_GVA
    printf "p15nfs8a.gv2.secutix.net\n" >> "$dir"host_GVA
    printf "pp1nfs8a.gv2.secutix.net\n" >> "$dir"host_GVA
    printf "p16nfs8a.gv2.secutix.net\n" >> "$dir"host_GVA
    printf "p20nfs8a.gv2.secutix.net\n" >> "$dir"host_GVA
    printf "p44nfs8a.gv2.secutix.net\n" >> "$dir"host_GVA
  fi
}

_getHost_setDataCenter() {
  echo > "$dir"host_iven
  if [[ "$awx_sites" == "hrp" ]] ; then
    cat "$dir"host_HRP >> "$dir"host_iven
    cat "$dir"host_SGN >> "$dir"host_iven
    cat "$dir"host_SD01 >> "$dir"host_iven
    group_env=(`cat /tmp/env | sed -e 's|, |\n|g' | tr -d "[" | tr -d "]" | grep -Po "(.*?)(?=HRP|SGN|SD01)" | sort -u`)
  fi
  if [[ "$awx_sites" == "seb" ]] ; then
    cat "$dir"host_SEB | grep -P "^\wp[1-9].*|^dm1.*|^qa.*|^t28.*|^t0.*" >> "$dir"host_iven
    cat "$dir"host_GVA | grep -P "^\wp[1-9].*|^perf15.*" >> "$dir"host_iven
    cat "$dir"host_EUCE >> "$dir"host_iven
    cat "$dir"host_USEA >> "$dir"host_iven
    group_seb=(`cat /tmp/env | sed -e 's|, |\n|g' | tr -d "[" | tr -d "]" | grep -Po "(.*?)(?=SEB)" | grep -P "^p[1-9].*" | sort -u`)
    for (( i = 0 ; i < ${#group_seb[@]} ; i++))
      do
        cat "$dir"host_SEB | grep -P "^${group_seb[$i]}\D.*" >> "$dir"host_iven
      done
    group_gva=(`cat /tmp/env | sed -e 's|, |\n|g' | tr -d "[" | tr -d "]" | grep -Po "(.*?)(?=GVA)" | grep -P "^p[1-9].*" | sort -u`)
    for (( i = 0 ; i < ${#group_gva[@]} ; i++))
      do
        cat "$dir"host_GVA | grep -P "^${group_gva[$i]}\D.*" >> "$dir"host_iven
      done
    group_env=(`cat /tmp/env | sed -e 's|, |\n|g' | tr -d "[" | tr -d "]" | grep -Po "(.*?)(?=SEB|GVA|EUCE|USEA)" | sort -u`)
  fi
}

_getHost_awx() {
  echo > "$dir"finalfile
  for (( i = 0 ; i < ${#group_env[@]} ; i++))
    do
      echo "[${group_env[$i]}]" >> "$dir"finalfile
      for (( j = 0 ; j < ${#group_machine[@]} ; j++))
        do
          cat "$dir"host_iven | grep -P "^${group_env[$i]}${group_machine[$j]}\d" >> "$dir"finalfile
        done
      printf "\n" >> "$dir"finalfile
    done
  for (( i = 0 ; i < ${#group_machine[@]} ; i++))
    do
      echo "[${group_machine[$i]}]" >> "$dir"finalfile
      cat "$dir"finalfile | grep -P "(?<=\d)(${group_machine[$i]})(?=\d)" >> "$dir"finalfile
      printf "\n" >> "$dir"finalfile
    done
  cat "$dir"finalfile | uniq > "$dir""awx_ocs/""$inventory"
  awx-manage inventory_import --inventory-name $inventory --source "$dir""awx_ocs/""$inventory" --overwrite
}

_getHost_prometheus() {
  for (( i = 0 ; i < ${#group_machine[@]} ; i++))
    do
      echo "[${group_machine[$i]}]" >> "$dir""prometheus_yml/autoPrometheus""$dc_tmp"
      for (( j = 0 ; j < ${#group_env[@]} ; j++))
        do
          cat "$dir"host_"$dc_tmp" | grep -P "^${group_env[$j]}${group_machine[$i]}\d" >> "$dir""prometheus_yml/autoPrometheus""$dc_tmp"
        done
        printf "\n" >> "$dir""prometheus_yml/autoPrometheus""$dc_tmp"
        if ! grep -qP "\d${group_machine[$i]}" "$dir""prometheus_yml/autoPrometheus""$dc_tmp"; then
          sed -i -e "s|\[${group_machine[$i]}\]||g" "$dir""prometheus_yml/autoPrometheus""$dc_tmp"
        fi
    done
}

_getHost_clean() {
  rm -rf "$dir"host* "$dir"prometheus_yml/auto* "$dir"finalfile
}

_getHost_extra() {
  printf "[jenkins]\n" >> "$dir"prometheus_yml/HRP
  printf "cs1jenkins1a.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "cs1jenkins1b.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "[qlik]\n" >> "$dir"prometheus_yml/HRP
  printf "cs1qlikce1a.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "cs1qlikrim1a.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "cs1qlikrim2a.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "[nas]\n" >> "$dir"prometheus_yml/SGN
  printf "cs1nas3a.sgn.secutix.net\n" >> "$dir"prometheus_yml/SGN
  printf "cs1nas2a.sgn.secutix.net\n" >> "$dir"prometheus_yml/SGN
  printf "[postgres]\n" >> "$dir"prometheus_yml/SEB
  printf "pp39postgresql1.mxp.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p39postgresql1.mxp.secutix.net\n" >> "$dir"prometheus_yml/SEB
}

_getHost_pkp() {
  printf "[pkp]\n" >> "$dir"prometheus_yml/HRP
  printf "cs1pkpbox1a.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "cs1pkpcontroller1a.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "cs1pkpcontroller1b.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "cs1pkpcontroller1c.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "cs1pkpmonitor1a.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "sup1pkpbox1a.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "sup1pkpcontroller1a.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "sup1pkpcontroller1b.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "sup1pkpmonitor1a.hrp.secutix.net\n" >> "$dir"prometheus_yml/HRP
  printf "[pkp]\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpbox1a.seb.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpbox2a.seb.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpmonitor1a.seb.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1a.seb.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1b.seb.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "pp1pkpbox1a.seb.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "pp1pkpmonitor1a.seb.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "pp1pkpcontroller1a.seb.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "pp1pkpcontroller1b.seb.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpbox1a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpbox3a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpmonitor1a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1b.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1c.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1d.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1e.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1f.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1g.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p16pkpbox1a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p16pkpmonitor1a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p16pkpcontroller1a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p16pkpcontroller1b.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p20pkpbox1a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p20pkpmonitor1a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p20pkpcontroller1a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p20pkpcontroller1b.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p20pkpcontroller1c.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p20pkpcontroller1d.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p44pkpbox1a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p44pkpmonitor1a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p44pkpcontroller1a.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p44pkpcontroller1b.gva.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpbox2a.euce.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpbox1a.euwe.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpmonitor1a.euwe.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1a.euwe.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1b.euwe.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1c.euwe.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1d.euwe.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1e.euwe.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpbox1a.usea.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpmonitor1a.usea.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1a.usea.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1b.usea.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1c.usea.secutix.net\n" >> "$dir"prometheus_yml/SEB
  printf "p1pkpcontroller1d.usea.secutix.net\n" >> "$dir"prometheus_yml/SEB
}


_getHost_run() {
  _getHost_setDataCenter
  _getHost_awx
  for (( b = 0 ; b < ${#data_center[@]} ; b++))
    do
      dc_tmp="${data_center[$b]}"
      group_env=(`cat /tmp/env | sed -e 's|, |\n|g' | tr -d "[" | tr -d "]" | grep -Po "(.*?)(?=$dc_tmp)"`)
      _getHost_prometheus
      cat "$dir""prometheus_yml/autoPrometheus""$dc_tmp" | uniq > "$dir""prometheus_yml/""$dc_tmp"
    done
}

_getHost_prepare
_getHost_run
_getHost_clean
_getHost_extra
_getHost_pkp
