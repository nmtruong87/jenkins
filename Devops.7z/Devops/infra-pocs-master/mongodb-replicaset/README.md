# MONGODB REPLICA SET
A replica set in MongoDB is a group of mongod processes that maintain the same data set. Replica sets provide redundancy and high availability, and are the basis for all production deployments. This ansible playbook in in charge of setting up a replica set.

It´s based on: https://docs.mongodb.com/manual/replication/.

## Usage
```bash
ansible-playbook -Kki env mongoreplicaset.yml
```

## Notes
- To run the ansible in "check mode" add the --check parameter
```bash
ansible-playbook -Kki env mongoreplicaset.yml --check
```

## Connection to the Replicaset
```bash
$ mongo --host rs0/PRIMARY_IP,SECONDARY_1_IP,SECONDARY_2_IP
use DB_NAME
db.auth("DB_USERNAME", "DB_PASSWORD")
db.test.insert({ok:1})
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
STX-ELCA